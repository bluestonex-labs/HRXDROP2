sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"../model/Backend",
	"../model/CurrentUser",
	"../model/formatter",
	"../model/BillingSchemes",
	"../model/RequiredFields",
	"../model/Toast"
], function (Controller, Fragment, DateFormat, JSONModel, Filter, FilterOperator, MessageToast, MessageBox, Backend, CurrentUser, formatter,
	BillingSchemes, RequiredFields, Toast) {
	"use strict";

	// Root path of the backend services - see xs-app.json (deployed) and ui5.yaml (local).
	var SERVICE_ROOT = Backend.SERVICE_ROOT;

	var PROJECTS_SERVICE = SERVICE_ROOT + "/hrx/manageProjects.xsjs";
	var ASSIGNMENTS_SERVICE = SERVICE_ROOT + "/hrx/manageAssignments.xsjs";
	var ATTACHMENTS_SERVICE = SERVICE_ROOT + "/hrx/manageAttachments.xsjs";

	var EMAIL_PATTERN = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

	// Dates as the design writes them, e.g. "1 Apr 2020".
	var DAY_FORMAT = DateFormat.getDateInstance({ pattern: "d MMM yyyy" });

	// The project list does not need the client logo, which is a base64 blob.
	var LIST_FIELDS = [
		"OrgID", "ProjectKey", "ProjectDesc", "ClientKey", "ProjectTypeKey", "StartDate",
		"EndDate", "PriorityKey", "PONumber", "POValue", "IsTimeBookingAllowed",
		"ProjectManagerID", "TotBillableDays", "ClientDesc", "ClientLocation"
	];

	return Controller.extend("bsx.hrx.hrx2026.controller.ManageProjects", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle                                                   */
		/* =========================================================== */

		onInit: function () {
			this._sOrgId = this._resolveOrgId();

			this.setModel(new JSONModel({
				// "list" (nothing open), "open" (list + project) or "full" (project only)
				layout: "list",
				fullScreen: false,
				listBusy: true,
				detailBusy: false,
				tabBusy: false,
				saving: false,
				title: this.getText("mpListTitle"),
				searchQuery: "",
				selectedId: null,
				selectedTab: "info",
				filter: this._defaultFilter(),
				filterDraft: this._defaultFilter()
			}), "mpView");

			this.setModel(new JSONModel({
				allProjects: [],
				projects: [],
				clients: [],
				// the filter's client choices: "All clients", then every client
				filterClients: [],
				projectTypes: [],
				priorities: [],
				managers: [],
				billing: [],
				tasks: [],
				// Whether the backend has project areas at all - see _loadLookups.
				tasksAvailable: true
			}), "mp");

			this.setModel(new JSONModel({}), "mpDetail");
			this.setModel(new JSONModel(this._emptyTabs()), "mpTabs");
			this.setModel(new JSONModel({}), "mpForm");
			this.setModel(new JSONModel({ title: "", text: "", action: "" }), "mpConfirm");

			this._pLookupsLoaded = this._loadLookups();

			this.getOwnerComponent().getRouter().getRoute("projects")
				.attachPatternMatched(this._onRouteMatched, this);
		},

		/**
		 * The view is reused across navigations, so entering the app always returns to
		 * the project list rather than to whatever was open before.
		 */
		_onRouteMatched: function () {
			var oViewModel = this.getModel("mpView");
			oViewModel.setProperty("/searchQuery", "");
			oViewModel.setProperty("/filter", this._defaultFilter());
			oViewModel.setProperty("/filterDraft", this._defaultFilter());
			this._closeDetail();
			this._pLookupsLoaded.then(this._loadProjects.bind(this));
		},

		/* =========================================================== */
		/* data loading                                                */
		/* =========================================================== */

		_loadLookups: function () {
			var oModel = this.getModel("mp");

			return Promise.all([
				this._read("/Clients", { filters: [new Filter("OrgID", FilterOperator.EQ, this._sOrgId)] }),
				this._read("/ProjectTypes", { filters: [new Filter("OrgID", FilterOperator.EQ, this._sOrgId)] }),
				this._read("/Priorities", { filters: [new Filter("OrgID", FilterOperator.EQ, this._sOrgId)] }),
				this._read("/Resources", {
					urlParameters: { "$select": "EmpID,FName,LName,IsActive,UserTypeKey" },
					filters: [new Filter("OrgID", FilterOperator.EQ, this._sOrgId)]
				}),
				this._read("/PredefinedBilling", { filters: [new Filter("OrgID", FilterOperator.EQ, this._sOrgId)] }),
				// Optional: some systems' services have no project areas at all, and a
				// 404 on this one used to fail every value help on the page with it.
				this._readOptional("/Task")
			]).then(function (aResults) {
				oModel.setProperty("/tasksAvailable",
					Backend.hasEntitySet(this.getOwnerComponent().getModel(), "/Task"));

				var aClients = this._strip(aResults[0]).sort(function (a, b) {
					return (a.ClientDesc || "").localeCompare(b.ClientDesc || "");
				});
				this._mClientNames = aClients.reduce(function (mNames, oClient) {
					mNames[oClient.ClientKey] = oClient.ClientDesc;
					return mNames;
				}, {});

				var aResources = this._strip(aResults[3])
					.filter(function (oResource) {
						return oResource.IsActive === "Y";
					})
					.map(function (oResource) {
						oResource.FullName = ((oResource.FName || "") + " " + (oResource.LName || "")).trim();
						return oResource;
					})
					.sort(function (a, b) {
						return a.FullName.localeCompare(b.FullName);
					});
				this._mResourceNames = aResources.reduce(function (mNames, oResource) {
					mNames[oResource.EmpID] = oResource.FullName;
					return mNames;
				}, {});

				oModel.setProperty("/clients", aClients);
				oModel.setProperty("/filterClients", [{
					ClientKey: "",
					ClientDesc: this.getText("mpFilterAllClients")
				}].concat(aClients));
				oModel.setProperty("/projectTypes", this._strip(aResults[1]));
				oModel.setProperty("/priorities", this._strip(aResults[2]));
				oModel.setProperty("/managers", aResources);
				oModel.setProperty("/billing", this._strip(aResults[4]));
				oModel.setProperty("/tasks", this._strip(aResults[5]).sort(function (a, b) {
					return (a.TaskDesc || "").localeCompare(b.TaskDesc || "");
				}));
			}.bind(this)).catch(function (oError) {
				this._showError("mpErrorLookups", oError);
			}.bind(this));
		},

		_loadProjects: function () {
			var oViewModel = this.getModel("mpView");
			oViewModel.setProperty("/listBusy", true);

			return this._read("/ProjectsData", {
				urlParameters: { "$select": LIST_FIELDS.join(",") },
				filters: [new Filter("OrgID", FilterOperator.EQ, this._sOrgId)]
			}).then(function (oData) {
				this.getModel("mp").setProperty("/allProjects", this._strip(oData));
				this._applyListFilters();
				oViewModel.setProperty("/listBusy", false);
			}.bind(this)).catch(function (oError) {
				oViewModel.setProperty("/listBusy", false);
				this._showError("mpErrorProjects", oError);
			}.bind(this));
		},

		_applyListFilters: function () {
			var oViewModel = this.getModel("mpView");
			var oFilter = oViewModel.getProperty("/filter");
			var sQuery = (oViewModel.getProperty("/searchQuery") || "").trim().toLowerCase();

			var aFiltered = (this.getModel("mp").getProperty("/allProjects") || []).filter(function (oProject) {
				if (oFilter.client && oProject.ClientKey !== oFilter.client) {
					return false;
				}
				if (oFilter.timeBooking !== "A" && (oProject.IsTimeBookingAllowed || "N") !== oFilter.timeBooking) {
					return false;
				}
				if (sQuery) {
					return [oProject.ProjectDesc, oProject.ProjectKey, oProject.ClientDesc, oProject.PONumber]
						.join(" ").toLowerCase().indexOf(sQuery) !== -1;
				}
				return true;
			}).sort(function (a, b) {
				var iByClient = (a.ClientDesc || "").localeCompare(b.ClientDesc || "");
				return iByClient !== 0 ? iByClient : (a.ProjectDesc || "").localeCompare(b.ProjectDesc || "");
			});

			this.getModel("mp").setProperty("/projects", aFiltered);
			oViewModel.setProperty("/title", this.getText("mpListTitleCount", [aFiltered.length]));
		},

		/**
		 * Opens a project in the detail column.
		 * @param {object} oKeys the ProjectKey/ClientKey pair identifying the project
		 * @returns {Promise} resolved once the project is shown
		 */
		_showProject: function (oKeys) {
			var oViewModel = this.getModel("mpView");

			oViewModel.setProperty("/selectedId", oKeys.ProjectKey);
			oViewModel.setProperty("/selectedClientKey", oKeys.ClientKey);
			oViewModel.setProperty("/selectedTab", "info");
			oViewModel.setProperty("/layout", oViewModel.getProperty("/fullScreen") ? "full" : "open");
			oViewModel.setProperty("/detailBusy", true);
			this.getModel("mpTabs").setData(this._emptyTabs());

			return Promise.all([
				this._read(Backend.keyPath("ProjectsData", {
					OrgID: this._sOrgId,
					ProjectKey: oKeys.ProjectKey,
					ClientKey: oKeys.ClientKey
				})),
				this._readOptional("/Proj_Task_Assign_Text", {
					filters: [new Filter("ProjectKey", FilterOperator.EQ, oKeys.ProjectKey)]
				})
			]).then(function (aResults) {
				this.getModel("mpDetail").setData(this._toDetail(aResults[0], this._strip(aResults[1])));
				oViewModel.setProperty("/detailBusy", false);
			}.bind(this)).catch(function (oError) {
				oViewModel.setProperty("/detailBusy", false);
				this._closeDetail();
				this._showError("mpErrorProjectDetail", oError);
			}.bind(this));
		},

		_toDetail: function (oProject, aProjectTasks) {
			return {
				OrgID: oProject.OrgID || this._sOrgId,
				ProjectKey: oProject.ProjectKey,
				ProjectDesc: oProject.ProjectDesc || "",
				ClientKey: oProject.ClientKey,
				ClientDesc: oProject.ClientDesc || this._clientName(oProject.ClientKey),
				ClientLocation: oProject.ClientLocation || "",
				ProjectTypeKey: oProject.ProjectTypeKey || "",
				PriorityKey: oProject.PriorityKey || "",
				ProjectManagerID: oProject.ProjectManagerID || "",
				PONumber: oProject.PONumber || "",
				POValue: oProject.POValue || "",
				TotBillableDays: oProject.TotBillableDays || "",
				StartDate: formatter.toDate(oProject.StartDate),
				EndDate: formatter.toDate(oProject.EndDate),
				IsTimeBookingAllowed: oProject.IsTimeBookingAllowed || "N",
				TimeBooking: oProject.IsTimeBookingAllowed === "Y",
				// The project areas double as the pool an assignment can draw from.
				taskKeys: aProjectTasks.map(function (oTask) {
					return oTask.TaskKey;
				}),
				projectTasks: aProjectTasks,
				// The client's contacts, as the two rows of the Client contacts tab
				contacts: [{
					role: this.getText("mpPrimaryContact"),
					name: oProject.PrimaryContactName || "",
					email: oProject.PrimaryContactEmail || ""
				}, {
					role: this.getText("mpSecondaryContact"),
					name: oProject.SecondaryContactName || "",
					email: oProject.SecondaryContactEmail || ""
				}],
				hasContacts: !!(oProject.PrimaryContactName || oProject.PrimaryContactEmail ||
					oProject.SecondaryContactName || oProject.SecondaryContactEmail)
			};
		},

		_clientName: function (sClientKey) {
			return (this._mClientNames && this._mClientNames[sClientKey]) || sClientKey || "";
		},

		_resourceName: function (sEmpId) {
			return (this._mResourceNames && this._mResourceNames[sEmpId]) || sEmpId || "";
		},

		/* =========================================================== */
		/* tabs                                                        */
		/* =========================================================== */

		onTabSelect: function (oEvent) {
			this._loadTab(oEvent.getParameter("key"));
		},

		_loadTab: function (sKey) {
			var oViewModel = this.getModel("mpView");
			var sProjectKey = oViewModel.getProperty("/selectedId");
			if (!sProjectKey) {
				return Promise.resolve();
			}

			switch (sKey) {
				case "resourcing":
					return this._loadAssignments(sProjectKey);
				case "attachments":
					return this._loadAttachments(sProjectKey);
				default:
					return Promise.resolve();
			}
		},

		_loadAssignments: function (sProjectKey) {
			return this._withTabBusy(this._getJson(ASSIGNMENTS_SERVICE + "?cmd=fetch&" + new URLSearchParams({
				orgID: this._sOrgId,
				projectKey: sProjectKey
			}).toString()).then(function (oData) {
				this.getModel("mpTabs").setProperty("/assignments", (oData.assignments || []).map(function (oAssignment) {
					oAssignment.FullName = ((oAssignment.Fname || oAssignment.FName || "") + " " +
						(oAssignment.Lname || oAssignment.LName || "")).trim();
					// TaskAssigned arrives as a JSON string on some rows and an array on others.
					if (typeof oAssignment.TaskAssigned === "string") {
						try {
							oAssignment.TaskAssigned = JSON.parse(oAssignment.TaskAssigned);
						} catch (oParseError) {
							oAssignment.TaskAssigned = [];
						}
					}
					oAssignment.TaskAssigned = oAssignment.TaskAssigned || [];
					return oAssignment;
				}));
			}.bind(this)), "mpErrorAssignments");
		},

		_loadAttachments: function (sProjectKey) {
			return this._withTabBusy(this._getJson(ATTACHMENTS_SERVICE + "?cmd=fetch&" + new URLSearchParams({
				OrgID: this._sOrgId,
				ProjectKey: sProjectKey
			}).toString()).then(function (oData) {
				this.getModel("mpTabs").setProperty("/attachments", oData.attachments || []);
			}.bind(this)), "mpErrorAttachments");
		},

		_withTabBusy: function (pWork, sErrorKey) {
			var oViewModel = this.getModel("mpView");
			oViewModel.setProperty("/tabBusy", true);

			return pWork.then(function () {
				oViewModel.setProperty("/tabBusy", false);
			}).catch(function (oError) {
				oViewModel.setProperty("/tabBusy", false);
				this._showError(sErrorKey, oError);
			}.bind(this));
		},

		/* =========================================================== */
		/* list events                                                 */
		/* =========================================================== */

		onSearch: function () {
			this._applyListFilters();
		},

		onRefresh: function () {
			var oViewModel = this.getModel("mpView");
			var sProjectKey = oViewModel.getProperty("/selectedId");
			var sClientKey = oViewModel.getProperty("/selectedClientKey");

			this._loadProjects().then(function () {
				if (sProjectKey) {
					this._showProject({ ProjectKey: sProjectKey, ClientKey: sClientKey });
				}
			}.bind(this));
		},

		onProjectSelect: function (oEvent) {
			var oItem = oEvent.getParameter("listItem");
			var oContext = oItem && oItem.getBindingContext("mp");
			if (oContext) {
				this._showProject(oContext.getObject());
			}
		},

		onCloseDetail: function () {
			this._closeDetail();
		},

		_closeDetail: function () {
			var oViewModel = this.getModel("mpView");
			oViewModel.setProperty("/layout", "list");
			oViewModel.setProperty("/fullScreen", false);
			oViewModel.setProperty("/selectedId", null);
			oViewModel.setProperty("/selectedClientKey", null);
			oViewModel.setProperty("/selectedTab", "info");
			this.getModel("mpDetail").setData({});
			this.getModel("mpTabs").setData(this._emptyTabs());
		},

		onToggleFullScreen: function () {
			var oViewModel = this.getModel("mpView");
			var bFullScreen = !oViewModel.getProperty("/fullScreen");
			oViewModel.setProperty("/fullScreen", bFullScreen);
			oViewModel.setProperty("/layout", bFullScreen ? "full" : "open");
		},

		/* =========================================================== */
		/* list filter                                                 */
		/* =========================================================== */

		onOpenFilter: function () {
			var oViewModel = this.getModel("mpView");
			oViewModel.setProperty("/filterDraft", Object.assign({}, oViewModel.getProperty("/filter")));
			this._openDialog("_pFilterDialog", "bsx.hrx.hrx2026.fragment.ProjectFilterDialog");
		},

		onConfirmFilter: function () {
			var oViewModel = this.getModel("mpView");
			oViewModel.setProperty("/filter", Object.assign({}, oViewModel.getProperty("/filterDraft")));
			this._applyListFilters();
			this._closeDialog("_pFilterDialog");
		},

		onCancelFilter: function () {
			this._closeDialog("_pFilterDialog");
		},

		/* =========================================================== */
		/* project info                                                */
		/* =========================================================== */

		/**
		 * Saves the project header, including the project areas it is broken down into.
		 */
		onSaveProject: function () {
			var oDetail = this.getModel("mpDetail").getData();

			if (!oDetail.ProjectKey) {
				return;
			}
			if (!this._validateRequired([{ id: "projectDesc", value: oDetail.ProjectDesc }])) {
				return;
			}

			this._save(PROJECTS_SERVICE + "?cmd=update", {
				ProjectKey: oDetail.ProjectKey,
				ProjectDesc: oDetail.ProjectDesc,
				ProjectTypeKey: oDetail.ProjectTypeKey || "",
				StartDate: this._isoDate(oDetail.StartDate),
				EndDate: this._isoDate(oDetail.EndDate),
				PriorityKey: oDetail.PriorityKey || "",
				PONumber: oDetail.PONumber || "",
				POValue: String(oDetail.POValue || "0"),
				IsTimeBookingAllowed: oDetail.TimeBooking ? "Y" : "N",
				ProjectManagerID: oDetail.ProjectManagerID || "",
				TotBillableDays: String(oDetail.TotBillableDays || "0"),
				ProjectTask: (oDetail.taskKeys || []).map(function (sTaskKey) {
					return { TaskKey: sTaskKey };
				})
			}, "mpSaved", "mpErrorSave").then(function () {
				return this._loadProjects().then(function () {
					return this._showProject({ ProjectKey: oDetail.ProjectKey, ClientKey: oDetail.ClientKey });
				}.bind(this));
			}.bind(this)).catch(function () { /* reported by _save */ });
		},

		/* =========================================================== */
		/* create project                                              */
		/* =========================================================== */

		onOpenAddProject: function () {
			// The design asks only for the name, client, type, manager and priority. A new
			// project starts today, is open-ended and open for booking; the rest is set on
			// its Info tab, which opens as soon as it is created.
			this.getModel("mpForm").setData({
				ProjectDesc: "",
				ClientKey: "",
				ProjectTypeKey: "",
				PriorityKey: "",
				ProjectManagerID: "",
				PONumber: "",
				POValue: "",
				TotBillableDays: "",
				StartDate: new Date(),
				EndDate: null,
				TimeBooking: true,
				taskKeys: []
			});
			this._openDialog("_pAddProjectDialog", "bsx.hrx.hrx2026.fragment.AddProjectDialog");
		},

		onCancelAddProject: function () {
			this._closeDialog("_pAddProjectDialog");
		},

		onCreateProject: function () {
			var oForm = this.getModel("mpForm").getData();

			// Every missing field is marked at once, not one per press of Create.
			var bDesc = this._validateRequired([{ id: "newProjectDesc", value: oForm.ProjectDesc }], true);
			var bPicked = this._validateSelection([
				{ id: "newProjectClient", value: oForm.ClientKey },
				{ id: "newProjectType", value: oForm.ProjectTypeKey }
			], true);
			if (!bDesc || !bPicked) {
				Toast.error(this.getText("mpMandatory"));
				return;
			}

			this._save(PROJECTS_SERVICE + "?cmd=new", {
				OrgID: this._sOrgId,
				ProjectKey: "",
				ProjectDesc: oForm.ProjectDesc.trim(),
				ClientKey: oForm.ClientKey,
				ProjectTypeKey: oForm.ProjectTypeKey,
				StartDate: this._isoDate(oForm.StartDate),
				EndDate: this._isoDate(oForm.EndDate),
				PriorityKey: oForm.PriorityKey || "",
				PONumber: oForm.PONumber || "",
				POValue: String(oForm.POValue || "0"),
				CreatedOn: this._today(),
				CreatedBy: "",
				IsTimeBookingAllowed: oForm.TimeBooking ? "Y" : "N",
				ProjectManagerID: oForm.ProjectManagerID || "",
				TotBillableDays: String(oForm.TotBillableDays || "0"),
				ProjectTask: (oForm.taskKeys || []).map(function (sTaskKey) {
					return { TaskKey: sTaskKey };
				})
			}, "mpCreated", "mpErrorCreate").then(function (oResult) {
				this._closeDialog("_pAddProjectDialog");
				return this._loadProjects().then(function () {
					// As in the design, the new project opens straight away.
					if (oResult && oResult.ProjectKey) {
						return this._showProject({ ProjectKey: oResult.ProjectKey, ClientKey: oForm.ClientKey });
					}
					return null;
				}.bind(this));
			}.bind(this)).catch(function () { /* reported by _save */ });
		},

		/* =========================================================== */
		/* resourcing                                                  */
		/* =========================================================== */

		onAddAssignment: function () {
			// Somebody already on the project is edited from their row, not assigned a
			// second time, so the picker only offers the people who are not on it yet.
			var aAssigned = (this.getModel("mpTabs").getProperty("/assignments") || []).map(function (oAssignment) {
				return oAssignment.EmpID;
			});

			this.getModel("mpForm").setData({
				mode: "new",
				resources: (this.getModel("mp").getProperty("/managers") || []).filter(function (oResource) {
					return aAssigned.indexOf(oResource.EmpID) === -1;
				}),
				AssignmentID: "",
				EmpID: "",
				schemes: this._billingOptions(),
				schemeKey: "",
				BillingID: "",
				DayRate: "",
				BillableDays: "",
				StartDate: null,
				IsActive: "Y",
				taskKeys: []
			});
			this._openDialog("_pAssignmentDialog", "bsx.hrx.hrx2026.fragment.AssignmentDialog");
		},

		onEditAssignment: function (oEvent) {
			var oAssignment = oEvent.getSource().getBindingContext("mpTabs").getObject();

			this.getModel("mpForm").setData({
				mode: "edit",
				// The picker is locked on an edit, but it still has to hold the person
				// being edited to show their name.
				resources: this.getModel("mp").getProperty("/managers") || [],
				AssignmentID: oAssignment.ASSIGNMENTID,
				EmpID: oAssignment.EmpID,
				schemes: this._billingOptions(),
				schemeKey: BillingSchemes.keyOf(oAssignment.BillingID, this.getModel("mp").getProperty("/billing")),
				BillingID: oAssignment.BillingID || "",
				DayRate: formatter.clean(oAssignment.DayRate),
				DayCost: formatter.clean(oAssignment.DayCost),
				BillableDays: formatter.clean(oAssignment.BillableDays),
				StartDate: formatter.toDate(oAssignment.AssignmentStartDate || oAssignment.StartDate),
				IsActive: oAssignment.IsActive || "Y",
				taskKeys: (oAssignment.TaskAssigned || []).map(function (oTask) {
					return oTask.ProjectTaskKey || oTask.TaskKey;
				})
			});
			this._openDialog("_pAssignmentDialog", "bsx.hrx.hrx2026.fragment.AssignmentDialog");
		},

		onCancelAssignment: function () {
			this._closeDialog("_pAssignmentDialog");
		},

		/**
		 * The billing schemes the Assign resource dialog offers: by office, as the
		 * live app has them (see model/BillingSchemes).
		 * @returns {Array<object>} key, text and the default day rate shown beside it
		 */
		_billingOptions: function () {
			return BillingSchemes.OPTIONS.map(function (oOption) {
				return {
					key: oOption.key,
					text: this.getText(oOption.textKey),
					rateText: oOption.dayRate === null ? "" : this.getText("mpBillingRate", [oOption.dayRate])
				};
			}, this);
		},

		/**
		 * Picking a billing scheme fills in its office's default day rate, which stays
		 * editable; a custom rate is left for the user to type.
		 * @param {sap.ui.base.Event} oEvent the selection change event
		 */
		onBillingSchemeChange: function (oEvent) {
			var oOption = BillingSchemes.option(oEvent.getSource().getSelectedKey());
			if (oOption && oOption.dayRate !== null) {
				this.getModel("mpForm").setProperty("/DayRate", String(oOption.dayRate));
			}
		},

		onSaveAssignment: function () {
			var oForm = this.getModel("mpForm").getData();
			var oDetail = this.getModel("mpDetail").getData();
			var bEdit = oForm.mode === "edit";

			var bPicked = this._validateSelection([
				{ id: "assignmentResource", value: oForm.EmpID },
				{ id: "assignmentBilling", value: oForm.schemeKey }
			], true);
			var bFilled = this._validateRequired([
				{ id: "assignmentDayRate", value: oForm.DayRate },
				{ id: "assignmentDays", value: oForm.BillableDays }
			], true);
			if (!bPicked || !bFilled) {
				Toast.error(this.getText("mpMandatory"));
				return;
			}

			// The chosen office's record in the service. On an edit that keeps a scheme
			// of no office (Custom), the assignment's own record stays as it is.
			var sBillingId = BillingSchemes.billingId(oForm.schemeKey, this.getModel("mp").getProperty("/billing"));
			if (!sBillingId && bEdit && oForm.schemeKey === BillingSchemes.keyOf(oForm.BillingID, this.getModel("mp").getProperty("/billing"))) {
				sBillingId = oForm.BillingID;
			}
			if (!sBillingId) {
				var oOption = BillingSchemes.option(oForm.schemeKey);
				MessageBox.error(this.getText("mpBillingNotInService", [oOption ? this.getText(oOption.textKey) : oForm.schemeKey]));
				return;
			}
			oForm.BillingID = sBillingId;

			var fDayRate = parseFloat(oForm.DayRate) || 0;
			var fDays = parseFloat(oForm.BillableDays) || 0;
			var aTasks = (oForm.taskKeys || []).map(function (sTaskKey) {
				return { ProjectTaskKey: sTaskKey };
			});

			var oPayload = bEdit ? {
				AssignmentID: oForm.AssignmentID,
				BillingID: oForm.BillingID,
				DayRate: String(fDayRate),
				DayCost: String(oForm.DayCost || ""),
				BillableDays: String(fDays),
				TotalCharge: String(fDayRate * fDays),
				StartDate: this._isoDate(oForm.StartDate),
				ProjectID: oDetail.ProjectKey,
				EmpID: oForm.EmpID,
				IsActive: oForm.IsActive || "Y",
				TaskAssigned: aTasks
			} : {
				OrgID: this._sOrgId,
				EmpID: oForm.EmpID,
				ProjectID: oDetail.ProjectKey,
				BillingID: oForm.BillingID,
				DayRate: String(fDayRate),
				DayCost: String(oForm.DayCost || ""),
				Currency: "GBP",
				BillableDays: String(fDays),
				TotalCharge: String(fDayRate * fDays),
				StartDate: this._isoDate(oForm.StartDate),
				EndDate: "",
				IsActive: "Y",
				TaskAssigned: aTasks
			};

			// The service expects a PUT for edits and a POST for new assignments.
			this._save(ASSIGNMENTS_SERVICE + (bEdit ? "?cmd=edit" : "?cmd=new"), oPayload,
				bEdit ? "mpAssignmentUpdated" : "mpAssignmentCreated", "mpErrorAssignmentSave",
				bEdit ? "PUT" : "POST").then(function () {
					this._closeDialog("_pAssignmentDialog");
					return this._loadAssignments(oDetail.ProjectKey);
				}.bind(this)).catch(function () { /* reported by _save */ });
		},

		onReleaseAssignment: function (oEvent) {
			var oAssignment = oEvent.getSource().getBindingContext("mpTabs").getObject();
			var sProjectKey = this.getModel("mpView").getProperty("/selectedId");

			this._confirm(
				this.getText("mpConfirmReleaseTitle"),
				this.getText("mpConfirmRelease", [oAssignment.FullName]),
				this.getText("mpRelease")
			).then(function (bConfirmed) {
				if (!bConfirmed) {
					return;
				}
				this._save(ASSIGNMENTS_SERVICE + "?cmd=release", {
					orgID: oAssignment.OrgID || this._sOrgId,
					empID: oAssignment.EmpID,
					projectID: oAssignment.ProjectKey || sProjectKey
				}, "mpAssignmentReleased", "mpErrorAssignmentRelease", "PUT").then(function () {
					return this._loadAssignments(sProjectKey);
				}.bind(this)).catch(function () { /* reported by _save */ });
			}.bind(this));
		},

		/**
		 * Puts a released resource back on the project.
		 * @param {sap.ui.base.Event} oEvent the Re-assign button's press event
		 */
		onReassignAssignment: function (oEvent) {
			var oAssignment = oEvent.getSource().getBindingContext("mpTabs").getObject();
			var sProjectKey = this.getModel("mpView").getProperty("/selectedId");

			this._save(ASSIGNMENTS_SERVICE + "?cmd=reassign", {
				orgID: oAssignment.OrgID || this._sOrgId,
				empID: oAssignment.EmpID,
				projectID: oAssignment.ProjectKey || sProjectKey
			}, "mpAssignmentReassigned", "mpErrorAssignmentReassign", "PUT").then(function () {
				return this._loadAssignments(sProjectKey);
			}.bind(this)).catch(function () { /* reported by _save */ });
		},

		/* =========================================================== */
		/* client contacts                                             */
		/* =========================================================== */

		onEditContacts: function () {
			var aContacts = this.getModel("mpDetail").getProperty("/contacts");
			this.getModel("mpForm").setData({
				PrimaryContactName: aContacts[0].name,
				PrimaryContactEmail: aContacts[0].email,
				SecondaryContactName: aContacts[1].name,
				SecondaryContactEmail: aContacts[1].email,
				state: {}
			});
			this._openDialog("_pContactsDialog", "bsx.hrx.hrx2026.fragment.ProjectContactsDialog");
		},

		onCancelContacts: function () {
			this._closeDialog("_pContactsDialog");
		},

		/**
		 * Checks the contacts as the design asks - a primary needs a name and an email,
		 * a secondary needs both or neither, every email must look like one - then
		 * saves them to the project.
		 */
		onSaveContacts: function () {
			var oFormModel = this.getModel("mpForm");
			var oForm = oFormModel.getData();
			var sProjectKey = this.getModel("mpView").getProperty("/selectedId");
			var oContacts = {
				PrimaryContactName: (oForm.PrimaryContactName || "").trim(),
				PrimaryContactEmail: (oForm.PrimaryContactEmail || "").trim(),
				SecondaryContactName: (oForm.SecondaryContactName || "").trim(),
				SecondaryContactEmail: (oForm.SecondaryContactEmail || "").trim()
			};

			var sProblem = this._contactsProblem(oContacts);
			oFormModel.setProperty("/state", sProblem ? sProblem.fields.reduce(function (oState, sField) {
				oState[sField] = "Error";
				return oState;
			}, {}) : {});
			if (sProblem) {
				Toast.error(this.getText(sProblem.textKey));
				return;
			}

			this._save(PROJECTS_SERVICE + "?cmd=saveContacts", Object.assign({ ProjectKey: sProjectKey }, oContacts),
				"mpContactsSaved", "mpErrorContactsSave", "PUT").then(function () {
					this._closeDialog("_pContactsDialog");
					var oDetailModel = this.getModel("mpDetail");
					oDetailModel.setProperty("/contacts/0/name", oContacts.PrimaryContactName);
					oDetailModel.setProperty("/contacts/0/email", oContacts.PrimaryContactEmail);
					oDetailModel.setProperty("/contacts/1/name", oContacts.SecondaryContactName);
					oDetailModel.setProperty("/contacts/1/email", oContacts.SecondaryContactEmail);
					oDetailModel.setProperty("/hasContacts", true);
				}.bind(this)).catch(function () { /* reported by _save */ });
		},

		/**
		 * The first thing wrong with the contacts, if anything.
		 * @param {object} oContacts the four trimmed contact fields
		 * @returns {object|null} { textKey, fields } naming the message and the fields to mark
		 */
		_contactsProblem: function (oContacts) {
			if (!oContacts.PrimaryContactName || !oContacts.PrimaryContactEmail) {
				return {
					textKey: "mpContactsPrimaryRequired",
					fields: ["PrimaryContactName", "PrimaryContactEmail"].filter(function (sField) {
						return !oContacts[sField];
					})
				};
			}
			if (!EMAIL_PATTERN.test(oContacts.PrimaryContactEmail)) {
				return { textKey: "mpContactsPrimaryEmail", fields: ["PrimaryContactEmail"] };
			}
			if (!!oContacts.SecondaryContactName !== !!oContacts.SecondaryContactEmail) {
				return {
					textKey: "mpContactsSecondaryBoth",
					fields: [oContacts.SecondaryContactName ? "SecondaryContactEmail" : "SecondaryContactName"]
				};
			}
			if (oContacts.SecondaryContactEmail && !EMAIL_PATTERN.test(oContacts.SecondaryContactEmail)) {
				return { textKey: "mpContactsSecondaryEmail", fields: ["SecondaryContactEmail"] };
			}
			return null;
		},

		/* =========================================================== */
		/* attachments                                                 */
		/* =========================================================== */

		/**
		 * Reads the chosen file and posts it to the attachment service as base64.
		 * @param {sap.ui.base.Event} oEvent the FileUploader change event
		 */
		onAttachmentChange: function (oEvent) {
			var aFiles = oEvent.getParameter("files");
			var oFile = aFiles && aFiles[0];
			var oUploader = oEvent.getSource();
			if (!oFile) {
				return;
			}

			var sProjectKey = this.getModel("mpView").getProperty("/selectedId");
			var oReader = new FileReader();

			oReader.onload = function (oLoadEvent) {
				// The service stores the raw base64 payload without the data: prefix.
				var sBase64 = String(oLoadEvent.target.result).split(",")[1] || "";

				this._save(ATTACHMENTS_SERVICE + "?cmd=new", {
					orgID: this._sOrgId,
					projectID: sProjectKey,
					fileName: oFile.name,
					fileType: oFile.type,
					attachment: sBase64,
					empID: "",
					uploadedOn: this._today()
				}, "mpAttachmentUploaded", "mpErrorAttachmentUpload").then(function () {
					oUploader.setValue("");
					return this._loadAttachments(sProjectKey);
				}.bind(this)).catch(function () {
					oUploader.setValue("");
				});
			}.bind(this);

			oReader.readAsDataURL(oFile);
		},

		onAttachmentTypeMismatch: function (oEvent) {
			Toast.error(this.getText("mpErrorFileType", [oEvent.getParameter("fileType")]));
		},

		/**
		 * Opens a stored attachment: from SAP Document Management when it is kept there
		 * (url), otherwise from the content the original service sends with the list.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 */
		onDownloadAttachment: function (oEvent) {
			var oAttachment = oEvent.getSource().getBindingContext("mpTabs").getObject();
			if (oAttachment.url) {
				window.open(oAttachment.url, "_blank", "noopener");
				return;
			}
			var sContent = oAttachment.Attachment || "";

			if (!sContent) {
				Toast.error(this.getText("mpErrorAttachmentEmpty"));
				return;
			}

			var sHref = sContent.indexOf("data:") === 0
				? sContent
				: "data:" + (oAttachment.FileType || "application/octet-stream") + ";base64," + sContent;

			var oLink = document.createElement("a");
			oLink.href = sHref;
			oLink.download = oAttachment.FileName || "attachment";
			document.body.appendChild(oLink);
			oLink.click();
			document.body.removeChild(oLink);
		},

		onDeleteAttachment: function (oEvent) {
			var oAttachment = oEvent.getSource().getBindingContext("mpTabs").getObject();
			var sProjectKey = this.getModel("mpView").getProperty("/selectedId");

			this._confirm(
				this.getText("mpConfirmDeleteAttachmentTitle"),
				this.getText("mpConfirmDeleteAttachment", [oAttachment.FileName]),
				this.getText("mpDeleteAttachment")
			).then(function (bConfirmed) {
				if (!bConfirmed) {
					return;
				}
				this._save(ATTACHMENTS_SERVICE + "?cmd=delete", {
					attachmentID: oAttachment.AttachmentID,
					orgID: this._sOrgId,
					projectID: sProjectKey
				}, "mpAttachmentDeleted", "mpErrorAttachmentDelete").then(function () {
					return this._loadAttachments(sProjectKey);
				}.bind(this)).catch(function () { /* reported by _save */ });
			}.bind(this));
		},

		/* =========================================================== */
		/* formatters                                                  */
		/* =========================================================== */

		/**
		 * @param {Date|string} vDate any date shape the services return
		 * @returns {string} the date as the design writes it, e.g. "1 Apr 2020"
		 */
		formatDay: function (vDate) {
			var oDate = formatter.toDate(vDate);
			return oDate ? DAY_FORMAT.format(oDate) : "";
		},

		/**
		 * @param {Date|string} vFrom the project's start
		 * @param {Date|string} vTo the project's end
		 * @returns {string} "1 Apr 2020 – 31 Dec 2029", or whichever end is known
		 */
		formatDateRange: function (vFrom, vTo) {
			var sFrom = this.formatDay(vFrom);
			var sTo = this.formatDay(vTo);
			if (sFrom && sTo) {
				return sFrom + " – " + sTo;
			}
			return sFrom || sTo;
		},

		/**
		 * @param {string|number} vAmount a day rate or day cost
		 * @returns {string} "£525/day", or a dash when there is none
		 */
		formatPerDay: function (vAmount) {
			var fAmount = parseFloat(vAmount);
			if (!fAmount) {
				return "—";
			}
			return this.getText("mpPerDay", [formatter.money(fAmount)]);
		},

		/**
		 * @param {Array<object>} aAreas the areas a resource works in: [{ TaskDesc }]
		 * @returns {string} their names, comma separated, or a dash when there are none
		 */
		formatAreaList: function (aAreas) {
			var aNames = (aAreas || []).map(function (oArea) {
				return oArea.TaskDesc;
			}).filter(Boolean);
			return aNames.length ? aNames.join(", ") : "—";
		},

		/**
		 * Whether an area chip is on.
		 * @param {string} sTaskKey the chip's area
		 * @param {Array<string>} aSelectedKeys the areas chosen
		 * @returns {boolean} true when the area is among them
		 */
		isAreaSelected: function (sTaskKey, aSelectedKeys) {
			return (aSelectedKeys || []).indexOf(sTaskKey) !== -1;
		},

		/* =========================================================== */
		/* area chips                                                  */
		/* =========================================================== */

		/**
		 * A chip on the Info tab: adds the area to the project, or takes it off.
		 * @param {sap.ui.base.Event} oEvent the chip's press event
		 */
		onToggleProjectArea: function (oEvent) {
			var sTaskKey = oEvent.getSource().getBindingContext("mp").getProperty("TaskKey");
			this._toggleArea(this.getModel("mpDetail"), sTaskKey);
		},

		/**
		 * A chip in the assignment modal: the resource works in that area, or not.
		 * @param {sap.ui.base.Event} oEvent the chip's press event
		 */
		onToggleAssignmentArea: function (oEvent) {
			var sTaskKey = oEvent.getSource().getBindingContext("mpDetail").getProperty("TaskKey");
			this._toggleArea(this.getModel("mpForm"), sTaskKey);
		},

		_toggleArea: function (oModel, sTaskKey) {
			var aSelectedKeys = (oModel.getProperty("/taskKeys") || []).slice();
			var iIndex = aSelectedKeys.indexOf(sTaskKey);

			if (iIndex === -1) {
				aSelectedKeys.push(sTaskKey);
			} else {
				aSelectedKeys.splice(iIndex, 1);
			}
			// A new array, so the chips' pressed bindings see the change.
			oModel.setProperty("/taskKeys", aSelectedKeys);
		},

		/* =========================================================== */
		/* confirmation modal                                          */
		/* =========================================================== */

		/**
		 * Asks before something that cannot be undone, in the design's modal.
		 * @param {string} sTitle the modal title, e.g. "Release resource"
		 * @param {string} sText the question
		 * @param {string} sAction the red button's text, e.g. "Release"
		 * @returns {Promise<boolean>} true when confirmed, false when cancelled
		 */
		_confirm: function (sTitle, sText, sAction) {
			this.getModel("mpConfirm").setData({ title: sTitle, text: sText, action: sAction });

			return new Promise(function (resolve) {
				this._fnConfirmResolve = resolve;
				this._bConfirmed = false;
				this._openDialog("_pConfirmDialog", "bsx.hrx.hrx2026.fragment.ProjectConfirmDialog");
			}.bind(this));
		},

		onConfirmAction: function () {
			this._bConfirmed = true;
			this._closeDialog("_pConfirmDialog");
		},

		onConfirmCancel: function () {
			this._closeDialog("_pConfirmDialog");
		},

		/** Answers _confirm once the modal has closed, however it was closed. */
		onConfirmDialogClosed: function () {
			if (this._fnConfirmResolve) {
				this._fnConfirmResolve(this._bConfirmed);
				this._fnConfirmResolve = null;
			}
		},

		/* =========================================================== */
		/* helpers                                                     */
		/* =========================================================== */

		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		setModel: function (oModel, sName) {
			this.getView().setModel(oModel, sName);
			return this;
		},

		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getText: function (sKey, aArgs) {
			return this.getResourceBundle().getText(sKey, aArgs);
		},

		_save: function (sUrl, oPayload, sSuccessKey, sErrorKey, sMethod) {
			var oViewModel = this.getModel("mpView");
			oViewModel.setProperty("/saving", true);

			return this._request(sUrl, {
				method: sMethod || "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(oPayload)
			}).then(function (oResult) {
				oViewModel.setProperty("/saving", false);
				MessageToast.show(oResult.msg || this.getText(sSuccessKey));
				return oResult;
			}.bind(this)).catch(function (oError) {
				oViewModel.setProperty("/saving", false);
				this._showError(sErrorKey, oError);
				throw oError;
			}.bind(this));
		},

		/**
		 * Marks each empty field red.
		 * @param {Array<{id: string, value: any}>} aFields the fields and their values
		 * @param {boolean} [bQuiet] true to leave the toast to the caller
		 * @returns {boolean} true when all are filled in
		 */
		_validateRequired: function (aFields, bQuiet) {
			var bValid = true;

			aFields.forEach(function (oField) {
				var oControl = this.byId(oField.id);
				var bFilled = !!String(oField.value === undefined || oField.value === null ? "" : oField.value).trim();
				RequiredFields.mark(oControl, bFilled, this.getText("mpMandatory"));
				bValid = bValid && bFilled;
			}, this);

			if (!bValid && !bQuiet) {
				Toast.error(this.getText("mpMandatory"));
			}
			return bValid;
		},

		/**
		 * Marks each list with nothing picked red.
		 * @param {Array<{id: string, value: any}>} aFields the lists and their keys
		 * @param {boolean} [bQuiet] true to leave the toast to the caller
		 * @returns {boolean} true when all have a pick
		 */
		_validateSelection: function (aFields, bQuiet) {
			var bValid = true;

			aFields.forEach(function (oField) {
				var oControl = this.byId(oField.id);
				var bFilled = !!oField.value;
				RequiredFields.mark(oControl, bFilled, this.getText("mpMandatory"));
				bValid = bValid && bFilled;
			}, this);

			if (!bValid && !bQuiet) {
				Toast.error(this.getText("mpMandatory"));
			}
			return bValid;
		},

		_read: function (sPath, mParameters) {
			// Backend.read, not a bare model.read: it waits for the service metadata,
			// including the retries Component.js makes after a failed first attempt, so
			// a momentary outage at startup no longer leaves every value help on the
			// page empty for the rest of the session.
			return Backend.read(this.getOwnerComponent().getModel(), sPath, mParameters);
		},

		/**
		 * For an entity set the backend may not have - see Backend.readOptional.
		 * @param {string} sPath the entity set path
		 * @param {object} [mParameters] read parameters
		 * @returns {Promise<object>} the response, or no rows when the set is absent
		 */
		_readOptional: function (sPath, mParameters) {
			return Backend.readOptional(this.getOwnerComponent().getModel(), sPath, mParameters);
		},

		_getJson: function (sUrl) {
			return this._request(sUrl, { method: "GET" });
		},

		_request: function (sUrl, oInit) {
			// Through Backend, which answers from the HRX service where it can.
			return Backend.request(sUrl, oInit);
		},

		_openDialog: function (sCacheKey, sFragmentName) {
			if (!this[sCacheKey]) {
				this[sCacheKey] = Fragment.load({
					id: this.getView().getId(),
					name: sFragmentName,
					controller: this
				}).then(function (oDialog) {
					this.getView().addDependent(oDialog);
					return oDialog;
				}.bind(this));
			}

			return this[sCacheKey].then(function (oDialog) {
				RequiredFields.reset(oDialog);
				oDialog.open();
				return oDialog;
			});
		},

		_closeDialog: function (sCacheKey) {
			if (this[sCacheKey]) {
				this[sCacheKey].then(function (oDialog) {
					oDialog.close();
				});
			}
		},

		_strip: function (oData) {
			return (oData.results || []).map(function (oRow) {
				var oCopy = Object.assign({}, oRow);
				delete oCopy.__metadata;
				return oCopy;
			});
		},

		_isoDate: function (vDate) {
			var oDate = formatter.toDate(vDate);
			if (!oDate) {
				return "";
			}
			var sMonth = String(oDate.getMonth() + 1).padStart(2, "0");
			var sDay = String(oDate.getDate()).padStart(2, "0");
			return oDate.getFullYear() + "-" + sMonth + "-" + sDay;
		},

		_today: function () {
			return this._isoDate(new Date());
		},

		_defaultFilter: function () {
			// As the design opens: every project, booking open or closed.
			return { client: "", timeBooking: "A" };
		},

		_emptyTabs: function () {
			return { assignments: [], attachments: [] };
		},

		_resolveOrgId: function () {
			this._sUserEmail = CurrentUser.email(this.getOwnerComponent());
			return CurrentUser.orgId(this.getOwnerComponent());
		},

		_errorText: function (oError) {
			if (!oError) {
				return "";
			}
			if (oError.message) {
				return oError.message;
			}
			if (oError.responseText) {
				try {
					var oBody = JSON.parse(oError.responseText);
					return oBody.msg || (oBody.error && oBody.error.message && oBody.error.message.value) || oError.responseText;
				} catch (oParseError) {
					return oError.responseText;
				}
			}
			return String(oError);
		},

		_showError: function (sTextKey, oError) {
			MessageBox.error(this.getText(sTextKey), {
				details: this._errorText(oError)
			});
		}
	});
});
