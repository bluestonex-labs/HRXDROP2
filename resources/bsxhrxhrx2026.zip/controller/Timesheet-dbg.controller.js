sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/m/GroupHeaderListItem",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	"../model/Backend",
	"../model/CurrentUser",
	"../model/formatter",
	"../model/Toast"
], function (Controller, Fragment, JSONModel, Filter, FilterOperator, Sorter, MessageToast, MessageBox, GroupHeaderListItem, Dialog, Button, Text, Backend, CurrentUser, formatter, Toast) {
	"use strict";

	// Root path of the backend services - see xs-app.json (deployed) and ui5.yaml (local).
	var TIMESHEET_SERVICE = Backend.TIMESHEET;

	// abbrev matches the day fields exposed by the /Resources OData entity.
	var DAYS = [
		{ key: "Mon", label: "Mon", schedule: "Monday", abbrev: "Mo" },
		{ key: "Tue", label: "Tue", schedule: "Tuesday", abbrev: "Tu" },
		{ key: "Wed", label: "Wed", schedule: "Wednesday", abbrev: "We" },
		{ key: "Thu", label: "Thu", schedule: "Thursday", abbrev: "Th" },
		{ key: "Fri", label: "Fri", schedule: "Friday", abbrev: "Fr" },
		{ key: "Sat", label: "Sat", schedule: "Saturday", abbrev: "Sa" },
		{ key: "Sun", label: "Sun", schedule: "Sunday", abbrev: "Su" }
	];

	// Internal bookings against this client never need a work description.
	var NO_COMMENT_CLIENT = "BSXCL0000000000";

	// Bluestonex itself: internal work is the only thing on a fresh timesheet, and
	// client projects are put there by the user with "Add Project(s)".
	var INTERNAL_CLIENT = "BSXCL0000000001";

	// A closed month can still be corrected during the first few working days of the next one.
	var GRACE_WORKING_DAYS = 3;

	// How long after the last change a booking is saved without pressing Save.
	var AUTO_SAVE_DELAY_MS = 1500;

	return Controller.extend("bsx.hrx.hrx2026.controller.Timesheet", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle                                                   */
		/* =========================================================== */

		onInit: function () {
			// The signed-in user is still being resolved at this point: reading the
			// email here (as this did) hands back "" on a browser refresh, and the
			// services read an empty Email as "match anybody" rather than "nobody" -
			// which is why refreshing inside the timesheet emptied the project list and
			// left only the bank holiday row. Every lookup now waits for the profile in
			// _onRouteMatched.
			this._sOrgId = CurrentUser.orgId(this.getOwnerComponent());
			this._sUserEmail = "";

			this.setModel(new JSONModel({
				busy: true,
				saving: false,
				weekStart: this._mondayOf(new Date()),
				weekLabel: "",
				currentEmail: "",
				userId: "",
				selectedCount: 0,
				dayHeaders: DAYS.map(function (oDay) {
					return { label: oDay.label, date: "", total: "" };
				}),
				weekBooked: "00:00",
				weekTarget: "00:00",
				weekPercent: 0,
				weekOver: false,
				// The auto-save line next to Save: "", saving, saved, waiting or error
				autoSaveState: "",
				autoSaveText: "",
				kpis: this._emptyKpis()
			}), "tsView");

			this.setModel(new JSONModel({
				rows: [],
				available: [],
				directory: []
			}), "ts");

			this._applyRowsGrouping();

			this.setModel(new JSONModel({ comment: "", label: "" }), "tsComment");

			// Client groups the user has folded away, keyed by group (client) name. Kept
			// for the session, so a folded group stays folded from week to week.
			this._mCollapsedGroups = {};

			this.getOwnerComponent().getRouter().getRoute("timesheet")
				.attachPatternMatched(this._onRouteMatched, this);

			// Changes are saved on the way out too: to another page, or out of the app.
			this.getOwnerComponent().getRouter().attachRouteMatched(this._onAnyRouteMatched, this);
			this._fnBeforeUnload = this._onBeforeUnload.bind(this);
			window.addEventListener("beforeunload", this._fnBeforeUnload);
		},

		onExit: function () {
			window.removeEventListener("beforeunload", this._fnBeforeUnload);
			clearTimeout(this._iAutoSaveTimer);
		},

		/**
		 * The view is reused across navigations, so every entry returns to the current
		 * week with fresh data.
		 */
		_onRouteMatched: function () {
			this.getModel("tsView").setProperty("/weekStart", this._mondayOf(new Date()));

			return CurrentUser.ready(this.getOwnerComponent()).then(function (oProfile) {
				this._sUserEmail = oProfile.email;
				this._sOrgId = oProfile.orgId;

				if (!this._sUserEmail) {
					this.getModel("tsView").setProperty("/busy", false);
					if (CurrentUser.shouldReportMissingIdentity()) {
						this._showError("tsErrorNoIdentity", null);
					}
					return undefined;
				}

				// Everybody sees only their own timesheet.
				this.getModel("tsView").setProperty("/currentEmail", this._sUserEmail);

				return this._loadWeek();
			}.bind(this));
		},

		/**
		 * Groups on client (project rows) or "Leave and holidays" (the non-working rows),
		 * sorted alphabetically - except the leave/holidays group, which always sorts last
		 * regardless of where its label would otherwise fall.
		 */
		_applyRowsGrouping: function () {
			var oBinding = this.byId("timesheetTable").getBinding("items");
			if (oBinding) {
				oBinding.sort(new Sorter("ClientDesc", false, true, this._compareGroups.bind(this)));
			}
		},

		_compareGroups: function (a, b) {
			// SorterProcessor upper-cases string values before handing them to a custom
			// comparator, so the group label needs the same treatment to compare equal.
			var sAbsences = this.getText("tsAbsences").toLocaleUpperCase();
			var bAIsAbsences = a === sAbsences;
			var bBIsAbsences = b === sAbsences;

			if (bAIsAbsences || bBIsAbsences) {
				return bAIsAbsences === bBIsAbsences ? 0 : (bAIsAbsences ? 1 : -1);
			}
			return (a || "").localeCompare(b || "");
		},

		/* =========================================================== */
		/* data loading                                                */
		/* =========================================================== */

		/**
		 * Loads the bookings of the week on screen and rebuilds the grid.
		 * @returns {Promise} resolved once the week is in the model
		 */
		_loadWeek: function () {
			var oViewModel = this.getModel("tsView");
			var oMonday = formatter.toDate(oViewModel.getProperty("/weekStart")) || this._mondayOf(new Date());
			var aDates = this._weekDates(oMonday);
			var sEmail = oViewModel.getProperty("/currentEmail");
			// 'gaurav.kumar@bluestonex.com';
			// var sorgid = 'BSX';

			oViewModel.setProperty("/busy", true);
			oViewModel.setProperty("/weekLabel", this._weekLabel(aDates[0], aDates[6]));
			this._setAutoSaveStatus("");
			oViewModel.setProperty("/selectedCount", 0);

			return Promise.all([
				this._getJson(TIMESHEET_SERVICE + "?cmd=fetch&" + new URLSearchParams({
					Email: sEmail,
					FromDate: this._isoDate(aDates[0]),
					ToDate: this._isoDate(aDates[6]),
					OrgID: this._sOrgId
					// sorgid
				}).toString()),
				this._loadWorkSchedule(sEmail)
			]).then(function (aResults) {
				var oData = aResults[0];
				var oUser = oData.user || {};

				oViewModel.setProperty("/userId", oUser.empID || "");
				oViewModel.setProperty("/pic", oUser.pic || "");
				this._oWorkSchedule = aResults[1];
				this._iDayMinutes = this._dayMinutes(oUser);
				this._oNonWorkingDates = this._nonWorkingDates(oData);

				this.getModel("ts").setProperty("/rows",
					this._defaultRows(this._buildRows(oData.assignments || [], aDates))
						.concat(this._buildNonWorkingRows(oData, aDates)));

				this._updateKpis(oUser, oData, aDates);
				this._recalculate();
				oViewModel.setProperty("/busy", false);
			}.bind(this)).catch(function (oError) {
				oViewModel.setProperty("/busy", false);
				this.getModel("ts").setProperty("/rows", []);
				this._recalculate();
				this._showError("tsErrorWeek", oError);
			}.bind(this));
		},

		/**
		 * Reads the resource's weekly work schedule straight from /Resources, rather than
		 * trusting whatever the timesheet fetch happens to echo back.
		 * @param {string} sEmail the resource whose schedule is being viewed
		 * @returns {Promise<object|null>} a day-name/flag map, or null when nothing was found
		 */
		_loadWorkSchedule: function (sEmail) {
			if (!sEmail) {
				return Promise.resolve(null);
			}

			return this._read("/Resources", {
				urlParameters: { "$select": "Email," + DAYS.map(function (oDay) { return oDay.abbrev; }).join(",") },
				// Matched below rather than filtered on Email here: that filter is
				// case-sensitive, and an email stored with capitals matched nobody.
				filters: [new Filter("OrgID", FilterOperator.EQ, this._sOrgId)]
			}).then(function (oData) {
				var oResource = this._strip(oData).filter(function (oRow) {
					return CurrentUser.sameEmail(oRow.Email, sEmail);
				})[0];
				if (!oResource) {
					return null;
				}

				var oSchedule = {};
				DAYS.forEach(function (oDay) {
					oSchedule[oDay.schedule] = oResource[oDay.abbrev];
				});
				return oSchedule;
			}.bind(this)).catch(function () {
				// A resource that isn't found, or a service hiccup, falls back to the
				// Mon-Fri default in _isWorkingDay rather than blocking the week from loading.
				return null;
			});
		},

		/**
		 * Turns the assignments and their time entries into one row per project, with a
		 * cell per day of the week.
		 * @param {Array<object>} aAssignments assignments returned by the service
		 * @param {Array<Date>} aDates the seven days of the week
		 * @returns {Array<object>} the grid rows
		 */
		_buildRows: function (aAssignments, aDates) {
			var mRows = {};

			aAssignments.forEach(function (oAssignment) {
				var sProjectId = oAssignment.ProjectID;
				if (mRows[sProjectId]) {
					return;
				}

				var iBillable = parseInt(oAssignment.BillableMins, 10) || 0;
				var iBilled = parseInt(oAssignment.TotalBilledMin, 10) || 0;

				mRows[sProjectId] = {
					ProjectID: sProjectId,
					project: oAssignment.ProjectDesc,
					ClientKey: oAssignment.ClientKey,
					ClientDesc: oAssignment.ClientDesc,
					PONo: formatter.clean(oAssignment.PONo),
					ProjectTypeText: oAssignment.ProjectTypeText,
					Billable: oAssignment.ProjectTypeText === "Billable",
					// Billable work booked beyond what the assignment allows for.
					Overbooked: oAssignment.ProjectTypeText === "Billable" && iBilled > iBillable,
					readOnly: false,
					// BlueStoneX's own projects are pinned to every sheet by _defaultRows
					// and are not the user's to remove, so they cannot be selected.
					deletable: oAssignment.ClientKey !== INTERNAL_CLIENT,
					days: this._buildDays(aDates, oAssignment.ClientKey !== NO_COMMENT_CLIENT)
				};
			}, this);

			// Time entries can arrive on any assignment row of the same project.
			aAssignments.forEach(function (oAssignment) {
				var oRow = mRows[oAssignment.ProjectID];
				var aEntries = oAssignment.TimeEntries;
				if (!oRow || !aEntries || !aEntries.length) {
					return;
				}

				aEntries.forEach(function (oEntry) {
					var iIndex = this._dayIndexOf(oEntry.Date, aDates);
					if (iIndex === -1) {
						return;
					}

					var oDay = oRow.days[iIndex];
					var sHours = this._trimSeconds(oEntry.Hours);

					oDay.recId = oEntry.RecID || "";
					oDay.time = sHours === "00:00" ? "" : sHours;
					oDay.comment = formatter.clean(oEntry.Comment);
					oDay.serviceTime = oDay.time;
					oDay.serviceComment = oDay.comment;
				}, this);
			}, this);

			return Object.keys(mRows).map(function (sKey) {
				return mRows[sKey];
			}).sort(function (a, b) {
				return (a.project || "").localeCompare(b.project || "");
			});
		},

		/**
		 * A week starts with internal work only - a consultant is assigned to far more
		 * client projects than they book against in any one week, so the rest are added
		 * on demand. Anything already booked stays on the sheet regardless.
		 * @param {Array<object>} aRows every row the assignments produced
		 * @returns {Array<object>} the rows to show by default
		 */
		_defaultRows: function (aRows) {
			return aRows.filter(function (oRow) {
				if (oRow.ClientKey === INTERNAL_CLIENT) {
					return true;
				}
				return oRow.days.some(function (oDay) {
					return !!oDay.time;
				});
			});
		},

		/**
		 * Leave and bank holidays are shown as read-only rows so the week total reflects
		 * them, exactly as the standalone app did.
		 * @param {object} oData the service response
		 * @param {Array<Date>} aDates the seven days of the week
		 * @returns {Array<object>} the non-working rows
		 */
		_buildNonWorkingRows: function (oData, aDates) {
			var aRows = [];

			[
				{ key: "bankHolidays", label: this.getText("tsBankHoliday") },
				{ key: "leaves", label: this.getText("tsLeave") }
			].forEach(function (oSource) {
				var aEntries = oSource.key === "leaves"
					? Backend.countedLeaves(oData.leaves)
					: (oData[oSource.key] || []);
				if (!aEntries.length) {
					return;
				}

				var oRow = {
					ProjectID: "NONWORK_" + oSource.key,
					project: oSource.label,
					ClientKey: "",
					// The grid groups by client, so absences need a group of their own.
					ClientDesc: this.getText("tsAbsences"),
					PONo: "",
					ProjectTypeText: "",
					Billable: false,
					Overbooked: false,
					readOnly: true,
					deletable: false,
					days: this._buildDays(aDates, false)
				};

				// Nothing on a leave or bank holiday row is bookable.
				oRow.days.forEach(function (oDay) {
					oDay.editable = false;
				});

				aEntries.forEach(function (oEntry) {
					var iIndex = this._dayIndexOf(oEntry.Date, aDates);
					if (iIndex === -1) {
						return;
					}
					var sHours = this._trimSeconds(oEntry.Hours);
					oRow.days[iIndex].time = sHours === "00:00" ? "" : sHours;
				}, this);

				aRows.push(oRow);
			}, this);

			return aRows;
		},

		/**
		 * @param {Array<Date>} aDates the seven days of the week
		 * @param {boolean} bCommentRequired whether a booking on this row needs a work description
		 * @returns {Array<object>} one cell per day
		 */
		_buildDays: function (aDates, bCommentRequired) {
			var mNonWorkingDates = this._oNonWorkingDates || {};
			var iDayMinutes = this._iDayMinutes;

			return DAYS.map(function (oDay, iIndex) {
				var oDate = aDates[iIndex];
				var sIsoDate = this._isoDate(oDate);
				return {
					key: oDay.key,
					date: sIsoDate,
					time: "",
					comment: "",
					recId: "",
					serviceTime: "",
					serviceComment: "",
					commentRequired: !!bCommentRequired,
					// Set by Save on a day booked without its work description; the
					// button only shows red then, and goes green once one is added.
					commentError: false,
					working: this._isWorkingDay(oDay.schedule),
					// A project row's own cell is locked on any day that is fully covered by
					// leave or a bank holiday, same as the dedicated absence rows, and on any
					// day the user's work schedule doesn't flag "Y". It used to lock on any
					// leave at all, which left a half day's other half unbookable. With no
					// weekly target to measure against, any leave still closes the day.
					editable: this._isWorkingDay(oDay.schedule) && this._isOpenForBooking(oDate) &&
						!(mNonWorkingDates[sIsoDate] && mNonWorkingDates[sIsoDate] >= (iDayMinutes || mNonWorkingDates[sIsoDate]))
				};
			}, this);
		},

		/**
		 * @param {object} oData the service response
		 * @returns {object} the minutes of leave and bank holiday on each of this week's
		 * dates, keyed by ISO date. A half day of leave (AM or PM) counts its four hours.
		 */
		_nonWorkingDates: function (oData) {
			var mDates = {};

			// Summed per day, so a half day's leave is four hours of the day rather
			// than the whole of it - see _buildDays.
			Backend.countedLeaves(oData.leaves).concat(oData.bankHolidays || []).forEach(function (oEntry) {
				var sDate = Backend.dayKey(oEntry.Date);
				mDates[sDate] = (mDates[sDate] || 0) + Backend.toMinutes(oEntry.Hours);
			});

			return mDates;
		},

		/**
		 * @param {object} oUser the user block of the timesheet response
		 * @returns {number} the minutes owed on a working day: the week's target spread
		 * over the days the work schedule has the user working
		 */
		_dayMinutes: function (oUser) {
			var iWorkingDays = DAYS.filter(function (oDay) {
				return this._isWorkingDay(oDay.schedule);
			}, this).length || 5;
			return Math.round(this._toMinutes((oUser || {}).targetHrsPerWeek) / iWorkingDays);
		},

		/**
		 * A day can be booked while its month is still open. A closed month stays open
		 * for corrections during the first few working days of the following month.
		 * @param {Date} oDate the day in question
		 * @returns {boolean} true when the day may still be edited
		 */
		_isOpenForBooking: function (oDate) {
			var oToday = new Date();
			var iMonthsBack = (oToday.getFullYear() - oDate.getFullYear()) * 12 + (oToday.getMonth() - oDate.getMonth());

			if (iMonthsBack <= 0) {
				return true;
			}
			if (iMonthsBack > 1) {
				return false;
			}
			return this._workingDaysSoFar(oToday) <= GRACE_WORKING_DAYS;
		},

		/**
		 * @param {Date} oToday today
		 * @returns {number} how many working days of the current month have passed
		 */
		_workingDaysSoFar: function (oToday) {
			var iWorkingDays = 0;
			for (var iDay = 1; iDay <= oToday.getDate(); iDay++) {
				var oDate = new Date(oToday.getFullYear(), oToday.getMonth(), iDay);
				var iWeekday = oDate.getDay();
				if (iWeekday !== 0 && iWeekday !== 6) {
					iWorkingDays++;
				}
			}
			return iWorkingDays;
		},

		_isWorkingDay: function (sScheduleKey) {
			if (!this._oWorkSchedule) {
				return sScheduleKey !== "Saturday" && sScheduleKey !== "Sunday";
			}
			return this._oWorkSchedule[sScheduleKey] !== "N";
		},

		/**
		 * Fills the header figures from the user block of the response.
		 * @param {object} oUser the user block
		 * @param {object} oData the whole response
		 * @param {Array<Date>} aDates the seven days of the week
		 */
		_updateKpis: function (oUser, oData, aDates) {
			var oViewModel = this.getModel("tsView");

			var fTargetDays = parseFloat(oUser.utilizationTargetDays) || 0;
			var fActualDays = parseFloat(oUser.CurrentMonthActualBilledDays) || 0;
			var iWorkingDays = parseInt(oUser.noOfWorkingDays, 10) || 0;
			var fUtilisation = iWorkingDays ? Math.round(fActualDays * 1000 / iWorkingDays) / 10 : 0;

			// Leave and bank holidays in this week reduce the hours the user owes.
			var iTargetMinutes = this._toMinutes(oUser.targetHrsPerWeek);
			iTargetMinutes -= Backend.countedLeaves(oData.leaves).reduce(function (iTotal, oEntry) {
				return iTotal + this._toMinutes(oEntry.Hours);
			}.bind(this), 0);
			iTargetMinutes -= (oData.bankHolidays || []).filter(function (oEntry) {
				return oEntry.Day !== "Saturday" && oEntry.Day !== "Sunday";
			}).reduce(function (iTotal, oEntry) {
				return iTotal + this._toMinutes(oEntry.Hours);
			}.bind(this), 0);

			this._iWeekTargetMinutes = Math.max(iTargetMinutes, 0);

			// The service sends the days unrounded (2.1666...), so they are shown to at
			// most two decimal places. The state and the utilisation above still work
			// from the exact figures.
			// The design shows the days to two decimal places ("2.94") and the
			// utilisation as a whole percentage.
			oViewModel.setProperty("/kpis", {
				targetDays: this._roundTo2(fTargetDays).toFixed(2),
				actualDays: this._roundTo2(fActualDays).toFixed(2),
				actualState: fActualDays >= fTargetDays ? "Good" : "Critical",
				utilisation: Math.round(fUtilisation),
				month: aDates[0].toLocaleDateString("en-GB", { month: "long", year: "numeric" })
			});
		},

		/**
		 * Rounds half up to two decimal places. Shifting by exponent rather than
		 * multiplying by 100 keeps 2.125 at 2.13: 2.125 * 100 is 212.49999999999997.
		 * @param {number} fValue the figure
		 * @returns {number} the figure to at most two decimal places
		 */
		_roundTo2: function (fValue) {
			var fRounded = Number(Math.round(fValue + "e2") + "e-2");
			// A figure already in exponent form (1e-7) does not take the shift.
			return isFinite(fRounded) ? fRounded : Math.round(fValue * 100) / 100;
		},

		/**
		 * Recomputes the per-day and weekly totals shown in the header and column titles.
		 */
		_recalculate: function () {
			var oViewModel = this.getModel("tsView");
			var aRows = this.getModel("ts").getProperty("/rows") || [];
			var oMonday = formatter.toDate(oViewModel.getProperty("/weekStart")) || this._mondayOf(new Date());
			var aDates = this._weekDates(oMonday);

			// Leave and bank holidays already reduce the weekly target, so counting them
			// as booked time as well would double up.
			var aBookableRows = aRows.filter(function (oRow) {
				return !oRow.readOnly;
			});

			// Each column title: the day, its date ("19 Oct") and the time booked on it
			var aHeaders = DAYS.map(function (oDay, iIndex) {
				var iMinutes = aBookableRows.reduce(function (iTotal, oRow) {
					return iTotal + this._toMinutes(oRow.days[iIndex].time);
				}.bind(this), 0);

				return {
					label: oDay.label,
					date: aDates[iIndex].getDate() + " " + aDates[iIndex].toLocaleDateString("en-GB", { month: "short" }),
					// "0:00", "7:30": no leading zero on the hours, as the old screen had it
					total: this._fromMinutes(iMinutes).replace(/^0(?=\d)/, "")
				};
			}, this);

			var iBooked = aBookableRows.reduce(function (iTotal, oRow) {
				return iTotal + oRow.days.reduce(function (iRowTotal, oDay) {
					return iRowTotal + this._toMinutes(oDay.time);
				}.bind(this), 0);
			}.bind(this), 0);
			var iTarget = this._iWeekTargetMinutes || 0;

			oViewModel.setProperty("/dayHeaders", aHeaders);
			oViewModel.setProperty("/weekBooked", this._fromMinutes(iBooked));
			oViewModel.setProperty("/weekTarget", this._fromMinutes(iTarget));
			oViewModel.setProperty("/weekPercent", iTarget ? Math.min(Math.round(iBooked * 100 / iTarget), 100) : 0);
			// More booked than the week asks for turns the bar red, as in the design.
			oViewModel.setProperty("/weekOver", iTarget > 0 && iBooked > iTarget);
		},

		/* =========================================================== */
		/* week navigation                                             */
		/* =========================================================== */

		onPreviousWeek: function () {
			this._stepWeek(-7);
		},

		onNextWeek: function () {
			this._stepWeek(7);
		},

		_stepWeek: function (iDays) {
			// The week on screen is saved before another one replaces it.
			this._flushAutoSave().then(function () {
				var oViewModel = this.getModel("tsView");
				var oMonday = formatter.toDate(oViewModel.getProperty("/weekStart")) || this._mondayOf(new Date());
				var oNext = new Date(oMonday.getFullYear(), oMonday.getMonth(), oMonday.getDate() + iDays);

				oViewModel.setProperty("/weekStart", oNext);
				this._loadWeek();
			}.bind(this));
		},

		onOpenWeekPicker: function (oEvent) {
			var oButton = oEvent.getSource();

			this._openPopover("_pWeekPicker", "bsx.hrx.hrx2026.fragment.WeekPickerPopover", oButton).then(function (oPopover) {
				// The fragment is shared with Missing Timesheets, so this page's look is
				// added here rather than in the fragment.
				oPopover.addStyleClass("hrxTsPopover");
				var oCalendar = this.byId("weekPickerCalendar");
				if (oCalendar) {
					oCalendar.removeAllSelectedDates();
					oCalendar.focusDate(formatter.toDate(this.getModel("tsView").getProperty("/weekStart")));
				}
			}.bind(this));
		},

		onWeekPicked: function (oEvent) {
			var aSelected = oEvent.getSource().getSelectedDates();
			var oDate = aSelected.length && aSelected[0].getStartDate();
			if (!oDate) {
				return;
			}

			this._closePopover("_pWeekPicker");
			this._flushAutoSave().then(function () {
				this.getModel("tsView").setProperty("/weekStart", this._mondayOf(oDate));
				this._loadWeek();
			}.bind(this));
		},

		onRefresh: function () {
			this._flushAutoSave().then(this._loadWeek.bind(this));
		},

		/* =========================================================== */
		/* time entry                                                  */
		/* =========================================================== */

		/**
		 * Normalises whatever the user typed into hh:mm and refreshes the totals.
		 * @param {sap.ui.base.Event} oEvent the input change event
		 */
		onTimeChange: function (oEvent) {
			var oInput = oEvent.getSource();
			var oContext = oInput.getBindingContext("ts");
			if (!oContext) {
				return;
			}

			var sValue = (oInput.getValue() || "").trim();
			var sNormalised = this._normaliseTime(sValue);

			if (sValue && sNormalised === null) {
				oInput.setValueState("Error");
				oInput.setValueStateText(this.getText("tsInvalidTime"));
				return;
			}

			oInput.setValueState("None");
			this.getModel("ts").setProperty(oContext.getPath() + "/time", sNormalised || "");
			// Clearing the time takes away the need for a description too.
			if (!sNormalised) {
				this.getModel("ts").setProperty(oContext.getPath() + "/commentError", false);
			}
			this._recalculate();
			this._scheduleAutoSave();
		},

		/**
		 * Accepts "7", "7:30", "7.5" or "730" and returns hh:mm.
		 * @param {string} sValue whatever was typed
		 * @returns {string|null} the normalised time, or null when it cannot be read
		 */
		_normaliseTime: function (sValue) {
			if (!sValue) {
				return "";
			}

			var aParts = /^(\d{1,2}):(\d{1,2})$/.exec(sValue);
			var iHours;
			var iMinutes;

			if (aParts) {
				iHours = parseInt(aParts[1], 10);
				iMinutes = parseInt(aParts[2], 10);
			} else if (/^\d{1,2}([.,]\d{1,2})?$/.test(sValue)) {
				var fValue = parseFloat(sValue.replace(",", "."));
				iHours = Math.floor(fValue);
				iMinutes = Math.round((fValue - iHours) * 60);
			} else if (/^\d{3,4}$/.test(sValue)) {
				iHours = parseInt(sValue.slice(0, sValue.length - 2), 10);
				iMinutes = parseInt(sValue.slice(-2), 10);
			} else {
				return null;
			}

			if (isNaN(iHours) || isNaN(iMinutes) || iMinutes > 59 || iHours > 24 || (iHours === 24 && iMinutes > 0)) {
				return null;
			}

			return String(iHours).padStart(2, "0") + ":" + String(iMinutes).padStart(2, "0");
		},

		/**
		 * Opens the work description for one cell.
		 * @param {sap.ui.base.Event} oEvent the button press event
		 */
		onOpenComment: function (oEvent) {
			var oContext = oEvent.getSource().getBindingContext("ts");
			if (!oContext) {
				return;
			}

			var oDay = oContext.getObject();
			var oRow = this.getModel("ts").getProperty(oContext.getPath().replace(/\/days\/\d+$/, ""));

			this._sCommentPath = oContext.getPath();
			this.getModel("tsComment").setData({
				comment: oDay.comment || "",
				label: oRow.project + " — " + formatter.date(oDay.date),
				editable: oDay.editable && !oRow.readOnly
			});

			this._openDialog("_pCommentDialog", "bsx.hrx.hrx2026.fragment.CommentPopover");
		},

		/**
		 * Writes the description back onto the cell and closes the dialog.
		 */
		onSaveComment: function () {
			if (this._sCommentPath) {
				var sComment = (this.getModel("tsComment").getProperty("/comment") || "").trim();
				this.getModel("ts").setProperty(this._sCommentPath + "/comment", sComment);
				if (sComment) {
					this.getModel("ts").setProperty(this._sCommentPath + "/commentError", false);
				}
				this._scheduleAutoSave();
			}
			this._sCommentPath = null;
			this._closeDialog("_pCommentDialog");
		},

		/**
		 * Closes the dialog and leaves the cell's description as it was.
		 */
		onCancelComment: function () {
			this._sCommentPath = null;
			this._closeDialog("_pCommentDialog");
		},

		/**
		 * Keeps the count behind the Delete button in step with the selection.
		 *
		 * Rows that may not be deleted are unselectable in the first place (see
		 * control/TimesheetRow), so there is nothing to take back here. This used to
		 * let "select all" reach them and then deselect them again, which is what left
		 * the select-all checkbox unticked even with every deletable row selected.
		 * @param {sap.ui.base.Event} oEvent the selectionChange event
		 */
		onSelectionChange: function (oEvent) {
			this.getModel("tsView").setProperty("/selectedCount", oEvent.getSource().getSelectedItems().length);
		},

		/**
		 * Drops every tick in the grid and the count behind the Delete button.
		 * selectionChange does not fire for a programmatic clear, so the count has to
		 * be put back by hand.
		 */
		_clearTableSelection: function () {
			var oTable = this.byId("timesheetTable");
			if (oTable) {
				oTable.removeSelections(true);
			}
			this.getModel("tsView").setProperty("/selectedCount", 0);
		},

		/* =========================================================== */
		/* client groups                                               */
		/* =========================================================== */

		/**
		 * Builds the row that heads each client's projects. Clicking it folds the
		 * group away or opens it again, as the design's group rows do.
		 * @param {object} oGroup the group the sorter produced
		 * @returns {sap.m.GroupHeaderListItem} the group row
		 */
		createGroupHeader: function (oGroup) {
			var oHeader = new GroupHeaderListItem({
				title: oGroup.key,
				type: "Active",
				press: this.onToggleGroup.bind(this)
			});

			oHeader.data("groupKey", oGroup.key);
			oHeader.toggleStyleClass("hrxTsGroupCollapsed", !!this._mCollapsedGroups[oGroup.key]);
			return oHeader;
		},

		/**
		 * Folds a client's projects away, or opens them again.
		 * @param {sap.ui.base.Event} oEvent the group row's press event
		 */
		onToggleGroup: function (oEvent) {
			var oHeader = oEvent.getSource();
			var sGroupKey = oHeader.data("groupKey");
			var bCollapsed = !this._mCollapsedGroups[sGroupKey];

			this._mCollapsedGroups[sGroupKey] = bCollapsed;
			oHeader.toggleStyleClass("hrxTsGroupCollapsed", bCollapsed);
			this._applyCollapsedGroups();
		},

		/**
		 * The rows are rebuilt whenever the week reloads or a project is added, so the
		 * folded groups are applied again each time the table has updated.
		 */
		onTableUpdated: function () {
			this._applyCollapsedGroups();
		},

		/**
		 * Hides every project row that sits under a folded group row.
		 */
		_applyCollapsedGroups: function () {
			var oTable = this.byId("timesheetTable");
			var bInCollapsedGroup = false;

			oTable.getItems().forEach(function (oItem) {
				if (oItem instanceof GroupHeaderListItem) {
					bInCollapsedGroup = !!this._mCollapsedGroups[oItem.data("groupKey")];
					return;
				}
				oItem.setVisible(!bInCollapsedGroup);
			}, this);
		},

		/* =========================================================== */
		/* formatters                                                  */
		/* =========================================================== */

		/**
		 * The state of a cell's work-description button, written to the DOM as
		 * data-comment, as the live app has it: "has" (green) once there is a
		 * description, "missing" (red) only after Save found time booked on the day
		 * without one, otherwise "none" - a plain button.
		 * @param {string} sComment the work description
		 * @param {boolean} bError whether Save flagged the day for a missing description
		 * @returns {string} has, missing or none
		 */
		formatCommentState: function (sComment, bError) {
			if (sComment) {
				return "has";
			}
			return bError ? "missing" : "none";
		},

		/**
		 * @param {string} sComment the work description
		 * @param {boolean} bRequired whether the row needs a description
		 * @returns {string} the description itself, or what the button is for
		 */
		formatCommentTooltip: function (sComment, bRequired) {
			if (sComment) {
				return sComment;
			}
			return this.getText(bRequired ? "tsCommentRequired" : "tsComment");
		},

		/**
		 * @param {string} sTarget the week's target, hh:mm
		 * @returns {string} "of 40:00 hrs this week"
		 */
		formatHoursOfTarget: function (sTarget) {
			return this.getText("tsHoursOfTarget", [sTarget || "00:00"]);
		},

		/* =========================================================== */
		/* add and remove projects                                     */
		/* =========================================================== */

		/**
		 * Offers the assignments that are not on the timesheet yet.
		 */
		onOpenAddProjects: function () {
			this._loadAvailable().then(function (bLoaded) {
				if (bLoaded) {
					this._openDialog("_pAddProjectsDialog", "bsx.hrx.hrx2026.fragment.AddTimesheetProjectsDialog");
				}
			}.bind(this));
		},

		/**
		 * Reads the assignments that are not on the timesheet yet into ts>/available.
		 * Shared with the phone's Add project sheet (MobileTimesheet).
		 * @returns {Promise<boolean>} true once they are in the model, false if the read
		 * failed (already reported)
		 */
		_loadAvailable: function () {
			var oViewModel = this.getModel("tsView");
			var aDates = this._weekDates(formatter.toDate(oViewModel.getProperty("/weekStart")));
			// var smail = 'gaurav.kumar@bluestonex.com';
			// var sorgid = 'BSX';

			oViewModel.setProperty("/saving", true);

			return this._getJson(TIMESHEET_SERVICE + "?cmd=fetchAssignments&" + new URLSearchParams({
				Email: oViewModel.getProperty("/currentEmail"),
				// smail,
				FromDate: this._isoDate(aDates[0]),
				ToDate: this._isoDate(aDates[6]),
				OrgID: this._sOrgId
				// sorgid
			}).toString()).then(function (oData) {
				var aExisting = (this.getModel("ts").getProperty("/rows") || []).map(function (oRow) {
					return oRow.ProjectID;
				});

				var mSeen = {};
				var aAvailable = (oData.assignments || []).filter(function (oAssignment) {
					if (aExisting.indexOf(oAssignment.ProjectID) !== -1 || mSeen[oAssignment.ProjectID]) {
						return false;
					}
					// Only the assignment's own flag decides. A blank one counts as active,
					// as it does in Manage Projects: only "N" marks an assignment closed.
					if (oAssignment.IsActive === "N") {
						return false;
					}
					mSeen[oAssignment.ProjectID] = true;
					return true;
				}).sort(function (a, b) {
					return (a.ProjectDesc || "").localeCompare(b.ProjectDesc || "");
				});

				this.getModel("ts").setProperty("/available", aAvailable);
				oViewModel.setProperty("/saving", false);
				return true;
			}.bind(this)).catch(function (oError) {
				oViewModel.setProperty("/saving", false);
				this._showError("tsErrorAssignments", oError);
				return false;
			}.bind(this));
		},

		onCancelAddProjects: function () {
			this._closeDialog("_pAddProjectsDialog");
		},

		onConfirmAddProjects: function () {
			var oTable = this.byId("addProjectsTable");
			var aSelected = oTable ? oTable.getSelectedItems() : [];

			if (!aSelected.length) {
				Toast.error(this.getText("tsSelectProject"));
				return;
			}

			this._addAssignments(aSelected.map(function (oItem) {
				return oItem.getBindingContext("ts").getObject();
			}));
			oTable.removeSelections(true);
			this._closeDialog("_pAddProjectsDialog");
		},

		/**
		 * Puts assignments on the timesheet as empty rows, in project order, with the
		 * leave and bank holiday rows kept at the bottom.
		 * @param {object[]} aAssignments entries of ts>/available
		 */
		_addAssignments: function (aAssignments) {
			var aDates = this._weekDates(formatter.toDate(this.getModel("tsView").getProperty("/weekStart")));
			var aRows = this.getModel("ts").getProperty("/rows") || [];

			aAssignments.forEach(function (oAssignment) {
				aRows.push({
					ProjectID: oAssignment.ProjectID,
					project: oAssignment.ProjectDesc,
					ClientKey: oAssignment.ClientKey,
					ClientDesc: oAssignment.ClientDesc,
					PONo: formatter.clean(oAssignment.PONo),
					ProjectTypeText: oAssignment.ProjectTypeText,
					Billable: oAssignment.ProjectTypeText === "Billable",
					Overbooked: false,
					readOnly: false,
					deletable: oAssignment.ClientKey !== INTERNAL_CLIENT,
					days: this._buildDays(aDates, oAssignment.ClientKey !== NO_COMMENT_CLIENT)
				});
			}, this);

			// Leave and bank holiday rows are read-only and must stay pinned to the
			// bottom of the list, so only the bookable project rows are re-sorted.
			var aBookable = aRows.filter(function (oRow) {
				return !oRow.readOnly;
			});
			var aNonWorking = aRows.filter(function (oRow) {
				return oRow.readOnly;
			});

			aBookable.sort(function (a, b) {
				return (a.project || "").localeCompare(b.project || "");
			});

			this.getModel("ts").setProperty("/rows", aBookable.concat(aNonWorking));
			this._recalculate();
		},

		/**
		 * Removes the selected rows. Anything already stored is deleted on the backend
		 * first; rows that were only added on screen simply disappear.
		 */
		onDeleteProjects: function () {
			var oTable = this.byId("timesheetTable");
			var aSelected = oTable ? oTable.getSelectedItems() : [];

			if (!aSelected.length) {
				Toast.error(this.getText("tsSelectRow"));
				return;
			}

			var aRows = this.getModel("ts").getProperty("/rows") || [];
			var aSelectedRows = aSelected.map(function (oItem) {
				return oItem.getBindingContext("ts").getObject();
			}).filter(function (oRow) {
				// onSelectionChange already refuses these, so this only guards against a
				// selection set some other way - but deleting one must never be possible.
				return oRow.deletable !== false;
			});

			if (!aSelectedRows.length) {
				Toast.error(this.getText("tsRowNotDeletable"));
				return;
			}
			var aNames = aSelectedRows.map(function (oRow) {
				return oRow.project;
			}).join(", ");

			this._confirmDelete(aNames, function () {
				this._flushAutoSave().then(this._deleteRows.bind(this, aRows, aSelectedRows));
			}.bind(this));
		},

		/**
		 * Removes the confirmed rows, through the service where they hold booked time.
		 * Shared with the phone's Remove project (MobileTimesheet).
		 * @param {Array<object>} aRows every row of the grid
		 * @param {Array<object>} aSelectedRows the rows to remove
		 * @returns {Promise} settles once the rows are gone (or the delete failed)
		 */
		_deleteRows: function (aRows, aSelectedRows) {
			var aRecIds = [];
			aSelectedRows.forEach(function (oRow) {
				oRow.days.forEach(function (oDay) {
					if (oDay.recId) {
						aRecIds.push({ RecID: oDay.recId });
					}
				});
			});

			var aRemaining = aRows.filter(function (oRow) {
				return aSelectedRows.indexOf(oRow) === -1;
			});

			var fnFinish = function () {
				this.getModel("ts").setProperty("/rows", aRemaining);
				this._clearTableSelection();
				this._recalculate();
			}.bind(this);

			if (!aRecIds.length) {
				fnFinish();
				return Promise.resolve();
			}

			// Rows carrying booked time go through the service and come back via
			// _loadWeek. That rebuilds the rows but leaves the table's own
			// selection behind, so the ticks - and the count that enables the
			// Delete button - have to be cleared here as well, on the way out
			// whether the delete succeeded or not.
			return this._save(TIMESHEET_SERVICE + "?cmd=delete", {
				OrgID: this._sOrgId,
				UserID: this.getModel("tsView").getProperty("/userId"),
				TimesheetListSet: aRecIds
			}, "tsDeleted", "tsErrorDelete").then(function () {
				return this._loadWeek();
			}.bind(this)).catch(function () { /* reported by _save */ })
				.then(this._clearTableSelection.bind(this));
		},

		/**
		 * Asks before removing projects, in the design's modal with a red action
		 * (the design's hrx.confirm).
		 * @param {string} sNames the projects about to be removed
		 * @param {function} fnConfirmed called once the user confirms
		 */
		_confirmDelete: function (sNames, fnConfirmed) {
			var oDialog = new Dialog({
				title: this.getText("tsConfirmDeleteTitle"),
				content: [
					new Text({ text: this.getText("tsConfirmDelete", [sNames]) }).addStyleClass("hrxModalText")
				],
				beginButton: new Button({
					text: this.getText("tsConfirmDeleteAction"),
					press: function () {
						oDialog.close();
						fnConfirmed();
					}
				}).addStyleClass("hrxModalBtn hrxModalBtnDanger"),
				endButton: new Button({
					text: this.getText("tsCancel"),
					press: function () {
						oDialog.close();
					}
				}).addStyleClass("hrxModalBtn hrxModalBtnGhost"),
				afterClose: function () {
					oDialog.destroy();
				}
			}).addStyleClass("hrxModal");

			this.getView().addDependent(oDialog);
			oDialog.open();
		},

		/* =========================================================== */
		/* save                                                        */
		/* =========================================================== */

		/**
		 * Saves every cell that was booked or cleared this session. A booking without a
		 * work description is rejected - managers rely on those to see what was worked on.
		 */
		onSave: function () {
			// An auto-save may be sending some of the same bookings; wait for it, so a
			// new booking is not created twice.
			clearTimeout(this._iAutoSaveTimer);
			this._iAutoSaveTimer = null;
			(this._pAutoSave || Promise.resolve()).then(this._saveAll.bind(this));
		},

		/**
		 * The Save button's work: every booked or cleared cell of the week.
		 */
		_saveAll: function () {
			var oViewModel = this.getModel("tsView");
			var aRows = this.getModel("ts").getProperty("/rows") || [];
			var aEntries = [];
			var bCommentMissing = false;

			aRows.forEach(function (oRow) {
				if (oRow.readOnly) {
					return;
				}

				oRow.days.forEach(function (oDay) {
					var bBooked = !!oDay.time && oDay.time !== "00:00";
					var bCleared = !oDay.time && !!oDay.serviceTime;

					// Marks the day red until a description is added (formatCommentState)
					oDay.commentError = bBooked && this._needsComment(oRow) && !oDay.comment;
					if (oDay.commentError) {
						bCommentMissing = true;
						return;
					}

					if (oDay.time) {
						aEntries.push({
							RecID: oDay.recId || "",
							ProjectKey: oRow.ProjectID,
							Date: oDay.date,
							Hours: oDay.time + ":00",
							Comment: oDay.comment || ""
						});
					} else if (bCleared) {
						aEntries.push({
							RecID: oDay.recId || "",
							ProjectKey: oRow.ProjectID,
							Date: oDay.date,
							Hours: "00:00:00",
							Comment: ""
						});
					}
				}, this);
			}, this);

			if (bCommentMissing) {
				this.getModel("ts").refresh(true);
				MessageBox.error(this.getText("tsErrorCommentMissing"));
				return;
			}
			this.getModel("ts").refresh(true);
			if (!aEntries.length) {
				MessageToast.show(this.getText("tsNothingToSave"));
				return;
			}

			var oNow = new Date();

			this._save(TIMESHEET_SERVICE + "?cmd=save", {
				OrgID: this._sOrgId,
				UserID: oViewModel.getProperty("/userId"),
				SavedOn: this._isoDate(oNow),
				SavedAt: this._clockTime(oNow),
				SavedBy: oViewModel.getProperty("/userId"),
				TimesheetListSet: aEntries
			}, "tsSaved", "tsErrorSave").then(function () {
				return this._loadWeek();
			}.bind(this)).catch(function () { /* reported by _save */ });
		},

		/**
		 * @param {object} oRow a grid row
		 * @returns {boolean} true when bookings on this row need a work description
		 */
		_needsComment: function (oRow) {
			return !oRow.readOnly && oRow.ClientKey !== NO_COMMENT_CLIENT;
		},

		/* =========================================================== */
		/* auto-save                                                   */
		/* =========================================================== */

		/**
		 * Saves the changed bookings shortly after the last change, so time is kept
		 * even when Save is never pressed.
		 */
		_scheduleAutoSave: function () {
			clearTimeout(this._iAutoSaveTimer);
			this._iAutoSaveTimer = setTimeout(this._autoSave.bind(this), AUTO_SAVE_DELAY_MS);
		},

		/**
		 * Saves now whatever is waiting to be saved.
		 * @returns {Promise} resolved once the changes are saved (or could not be)
		 */
		_flushAutoSave: function () {
			if (this._iAutoSaveTimer || this._changedCells().entries.length) {
				return this._autoSave();
			}
			return this._pAutoSave || Promise.resolve();
		},

		/**
		 * The cells changed since they were last read or saved. A booking that needs a
		 * work description and has none waits until it has one.
		 * @returns {{entries: Array<object>, waiting: Array<string>}} the cells to save,
		 * and the days held back for want of a description
		 */
		_changedCells: function () {
			var aEntries = [];
			var aWaiting = [];

			(this.getModel("ts").getProperty("/rows") || []).forEach(function (oRow) {
				if (oRow.readOnly) {
					return;
				}
				oRow.days.forEach(function (oDay, iIndex) {
					var bChanged = (oDay.time || "") !== (oDay.serviceTime || "") ||
						(oDay.comment || "") !== (oDay.serviceComment || "");
					if (!bChanged || (!oDay.time && !oDay.serviceTime)) {
						return;
					}
					if (oDay.time && this._needsComment(oRow) && !oDay.comment) {
						if (aWaiting.indexOf(DAYS[iIndex].label) === -1) {
							aWaiting.push(DAYS[iIndex].label);
						}
						return;
					}
					aEntries.push({ row: oRow, day: oDay });
				}, this);
			}, this);

			return { entries: aEntries, waiting: aWaiting };
		},

		/**
		 * Sends the changed cells, quietly - no busy state and no pop-ups while typing.
		 * @returns {Promise} resolved once they are saved (or could not be)
		 */
		_autoSave: function () {
			clearTimeout(this._iAutoSaveTimer);
			this._iAutoSaveTimer = null;

			// One at a time: a change made meanwhile goes in the next round.
			if (this._pAutoSave) {
				this._bAutoSaveAgain = true;
				return this._pAutoSave;
			}
			var oViewModel = this.getModel("tsView");
			if (oViewModel.getProperty("/saving") || oViewModel.getProperty("/busy")) {
				this._scheduleAutoSave();
				return Promise.resolve();
			}

			var oChanges = this._changedCells();
			if (!oChanges.entries.length) {
				this._setAutoSaveStatus(oChanges.waiting.length ? "waiting" : "", oChanges.waiting);
				return Promise.resolve();
			}

			var oMonday = oViewModel.getProperty("/weekStart");
			// What was sent, so a change typed while saving is not marked as saved
			var aSent = oChanges.entries.map(function (oChange) {
				return { day: oChange.day, time: oChange.day.time || "", comment: oChange.day.comment || "" };
			});
			var bNewBookings = oChanges.entries.some(function (oChange) {
				return !oChange.day.recId;
			});
			var oNow = new Date();

			this._setAutoSaveStatus("saving");
			this._pAutoSave = this._request(TIMESHEET_SERVICE + "?cmd=save", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					OrgID: this._sOrgId,
					UserID: oViewModel.getProperty("/userId"),
					SavedOn: this._isoDate(oNow),
					SavedAt: this._clockTime(oNow),
					SavedBy: oViewModel.getProperty("/userId"),
					TimesheetListSet: oChanges.entries.map(function (oChange) {
						var oDay = oChange.day;
						return {
							RecID: oDay.recId || "",
							ProjectKey: oChange.row.ProjectID,
							Date: oDay.date,
							Hours: oDay.time ? oDay.time + ":00" : "00:00:00",
							Comment: oDay.time ? oDay.comment || "" : ""
						};
					})
				})
			}).then(function () {
				aSent.forEach(function (oSent) {
					oSent.day.serviceTime = oSent.time;
					oSent.day.serviceComment = oSent.comment;
				});
				// A new booking needs its record ID before it is saved again, or the
				// service would create it a second time.
				return bNewBookings ? this._readRecordIds(oMonday) : null;
			}.bind(this)).then(function () {
				this._pAutoSave = null;
				var oLeft = this._changedCells();
				this._setAutoSaveStatus(oLeft.waiting.length ? "waiting" : "saved", oLeft.waiting);
				if (this._bAutoSaveAgain) {
					this._bAutoSaveAgain = false;
					return this._autoSave();
				}
				return null;
			}.bind(this)).catch(function () {
				this._pAutoSave = null;
				this._bAutoSaveAgain = false;
				this._setAutoSaveStatus("error");
			}.bind(this));

			return this._pAutoSave;
		},

		/**
		 * Reads the week again and copies the record IDs of new bookings onto their
		 * cells - without touching what is on screen.
		 * @param {Date} oMonday the week that was saved
		 * @returns {Promise} resolved once the IDs are in
		 */
		_readRecordIds: function (oMonday) {
			var oViewModel = this.getModel("tsView");
			if (oViewModel.getProperty("/weekStart") !== oMonday) {
				return Promise.resolve();
			}
			var aDates = this._weekDates(formatter.toDate(oMonday));

			return this._getJson(TIMESHEET_SERVICE + "?cmd=fetch&" + new URLSearchParams({
				Email: oViewModel.getProperty("/currentEmail"),
				FromDate: this._isoDate(aDates[0]),
				ToDate: this._isoDate(aDates[6]),
				OrgID: this._sOrgId
			}).toString()).then(function (oData) {
				var mRows = {};
				(this.getModel("ts").getProperty("/rows") || []).forEach(function (oRow) {
					if (!oRow.readOnly) {
						mRows[oRow.ProjectID] = oRow;
					}
				});
				(oData.assignments || []).forEach(function (oAssignment) {
					var oRow = mRows[oAssignment.ProjectID];
					(oAssignment.TimeEntries || []).forEach(function (oEntry) {
						var iIndex = this._dayIndexOf(oEntry.Date, aDates);
						if (oRow && iIndex !== -1 && !oRow.days[iIndex].recId) {
							oRow.days[iIndex].recId = oEntry.RecID || "";
						}
					}, this);
				}, this);
			}.bind(this));
		},

		/**
		 * The line next to Save.
		 * @param {string} sState "", saving, saved, waiting or error
		 * @param {Array<string>} [aWaiting] the days waiting for a description
		 */
		_setAutoSaveStatus: function (sState, aWaiting) {
			var oViewModel = this.getModel("tsView");
			var mText = {
				saving: this.getText("tsAutoSaving"),
				saved: this.getText("tsAutoSaved"),
				waiting: this.getText("tsAutoWaiting", [(aWaiting || []).join(", ")]),
				error: this.getText("tsAutoError")
			};
			oViewModel.setProperty("/autoSaveState", sState);
			oViewModel.setProperty("/autoSaveText", mText[sState] || "");
		},

		/**
		 * Leaving My Timesheet for another page saves what is waiting.
		 * @param {sap.ui.base.Event} oEvent the router's routeMatched event
		 */
		_onAnyRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") !== "timesheet") {
				this._flushAutoSave();
			}
		},

		/**
		 * Closing or reloading the tab: start saving, and let the browser ask before
		 * leaving while something is still unsaved.
		 * @param {Event} oEvent the window's beforeunload event
		 */
		_onBeforeUnload: function (oEvent) {
			var oChanges = this._changedCells();
			if (!this._iAutoSaveTimer && !this._pAutoSave && !oChanges.entries.length && !oChanges.waiting.length) {
				return;
			}
			this._autoSave();
			oEvent.preventDefault();
			oEvent.returnValue = "";
		},

		/* =========================================================== */
		/* helpers                                                     */
		/* =========================================================== */

		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		setModel: function (oModel, sName) {
			this.getView().setModel(oModel, sName);
			return this;
		},

		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getText: function (sKey, aArgs) {
			return this.getResourceBundle().getText(sKey, aArgs);
		},

		_save: function (sUrl, oPayload, sSuccessKey, sErrorKey) {
			var oViewModel = this.getModel("tsView");
			oViewModel.setProperty("/saving", true);

			return this._request(sUrl, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(oPayload)
			}).then(function (oResult) {
				oViewModel.setProperty("/saving", false);
				MessageToast.show(oResult.msg || this.getText(sSuccessKey));
				return oResult;
			}.bind(this)).catch(function (oError) {
				oViewModel.setProperty("/saving", false);
				this._showError(sErrorKey, oError);
				throw oError;
			}.bind(this));
		},

		_read: function (sPath, mParameters) {
			// Backend.read, not a bare model.read: it waits for the service metadata,
			// including the retries Component.js makes after a failed first attempt, so
			// a momentary outage at startup no longer leaves every value help on the
			// page empty for the rest of the session.
			return Backend.read(this.getOwnerComponent().getModel(), sPath, mParameters);
		},

		_getJson: function (sUrl) {
			return this._request(sUrl, { method: "GET" });
		},

		_request: function (sUrl, oInit) {
			// Through Backend, which answers from the HRX service where it can.
			return Backend.request(sUrl, oInit);
		},

		_openDialog: function (sCacheKey, sFragmentName) {
			return this._loadFragment(sCacheKey, sFragmentName).then(function (oDialog) {
				oDialog.open();
				return oDialog;
			});
		},

		_closeDialog: function (sCacheKey) {
			if (this[sCacheKey]) {
				this[sCacheKey].then(function (oDialog) {
					oDialog.close();
				});
			}
		},

		_openPopover: function (sCacheKey, sFragmentName, oBy) {
			return this._loadFragment(sCacheKey, sFragmentName).then(function (oPopover) {
				oPopover.openBy(oBy);
				return oPopover;
			});
		},

		_closePopover: function (sCacheKey) {
			if (this[sCacheKey]) {
				this[sCacheKey].then(function (oPopover) {
					oPopover.close();
				});
			}
		},

		_loadFragment: function (sCacheKey, sFragmentName) {
			if (!this[sCacheKey]) {
				this[sCacheKey] = Fragment.load({
					id: this.getView().getId(),
					name: sFragmentName,
					controller: this
				}).then(function (oControl) {
					this.getView().addDependent(oControl);
					return oControl;
				}.bind(this));
			}
			return this[sCacheKey];
		},

		_strip: function (oData) {
			return (oData.results || []).map(function (oRow) {
				var oCopy = Object.assign({}, oRow);
				delete oCopy.__metadata;
				return oCopy;
			});
		},

		/**
		 * @param {Date} oDate any day
		 * @returns {Date} the Monday of that day's week
		 */
		_mondayOf: function (oDate) {
			var oCopy = new Date(oDate.getFullYear(), oDate.getMonth(), oDate.getDate());
			var iOffset = (oCopy.getDay() + 6) % 7;
			oCopy.setDate(oCopy.getDate() - iOffset);
			return oCopy;
		},

		_weekDates: function (oMonday) {
			return DAYS.map(function (oDay, iIndex) {
				return new Date(oMonday.getFullYear(), oMonday.getMonth(), oMonday.getDate() + iIndex);
			});
		},

		_dayIndexOf: function (sDate, aDates) {
			for (var iIndex = 0; iIndex < aDates.length; iIndex++) {
				if (this._isoDate(aDates[iIndex]) === Backend.dayKey(sDate)) {
					return iIndex;
				}
			}
			return -1;
		},

		/**
		 * Durations arrive either as hh:mm:ss or already as hh:mm, so only a third part
		 * may be dropped - trimming unconditionally would eat the minutes.
		 * @param {string} sHours a duration
		 * @returns {string} the duration as hh:mm
		 */
		_trimSeconds: function (sHours) {
			if (!sHours || sHours === "None") {
				return "";
			}
			var aParts = String(sHours).split(":");
			return aParts.length > 2 ? aParts[0] + ":" + aParts[1] : String(sHours);
		},

		_toMinutes: function (sTime) {
			if (!sTime) {
				return 0;
			}
			var aParts = String(sTime).split(":");
			return (parseInt(aParts[0], 10) || 0) * 60 + (parseInt(aParts[1], 10) || 0);
		},

		/**
		 * @param {number} iMinutes a duration in minutes
		 * @returns {string} the duration as hh:mm, e.g. "24:30" or "00:00"
		 */
		_fromMinutes: function (iMinutes) {
			return String(Math.floor(iMinutes / 60)).padStart(2, "0") + ":" + String(iMinutes % 60).padStart(2, "0");
		},

		/**
		 * The week as the design titles it: "13th - 19th July", "29th June - 5th July",
		 * with the year added when the week runs into the next one.
		 * @param {Date} oMonday the first day of the week
		 * @param {Date} oSunday the last day of the week
		 * @returns {string} the week title
		 */
		_weekLabel: function (oMonday, oSunday) {
			var sFromMonth = oMonday.toLocaleDateString("en-GB", { month: "long" });
			var sToMonth = oSunday.toLocaleDateString("en-GB", { month: "long" });
			var sLabel;

			if (oMonday.getMonth() === oSunday.getMonth()) {
				sLabel = this._ordinal(oMonday.getDate()) + " - " + this._ordinal(oSunday.getDate()) + " " + sToMonth;
			} else {
				sLabel = this._ordinal(oMonday.getDate()) + " " + sFromMonth + " - " +
					this._ordinal(oSunday.getDate()) + " " + sToMonth;
			}

			if (oMonday.getFullYear() !== oSunday.getFullYear()) {
				sLabel += " " + oSunday.getFullYear();
			}
			return sLabel;
		},

		/**
		 * @param {number} iDay a day of the month
		 * @returns {string} the day with its English ordinal suffix, e.g. "1st", "13th", "22nd"
		 */
		_ordinal: function (iDay) {
			if (iDay >= 11 && iDay <= 13) {
				return iDay + "th";
			}
			switch (iDay % 10) {
				case 1:
					return iDay + "st";
				case 2:
					return iDay + "nd";
				case 3:
					return iDay + "rd";
				default:
					return iDay + "th";
			}
		},

		/**
		 * @param {Date} oDate a moment
		 * @returns {string} the time as hh:mm:ss, zero padded
		 */
		_clockTime: function (oDate) {
			return [oDate.getHours(), oDate.getMinutes(), oDate.getSeconds()].map(function (iPart) {
				return String(iPart).padStart(2, "0");
			}).join(":");
		},

		_isoDate: function (vDate) {
			var oDate = formatter.toDate(vDate);
			if (!oDate) {
				return "";
			}
			var sMonth = String(oDate.getMonth() + 1).padStart(2, "0");
			var sDay = String(oDate.getDate()).padStart(2, "0");
			return oDate.getFullYear() + "-" + sMonth + "-" + sDay;
		},

		_emptyKpis: function () {
			return { targetDays: 0, actualDays: 0, actualState: "Neutral", utilisation: 0, month: "" };
		},

		_errorText: function (oError) {
			if (!oError) {
				return "";
			}
			if (oError.message) {
				return oError.message;
			}
			if (oError.responseText) {
				try {
					var oBody = JSON.parse(oError.responseText);
					return oBody.msg || (oBody.error && oBody.error.message && oBody.error.message.value) || oError.responseText;
				} catch (oParseError) {
					return oError.responseText;
				}
			}
			return String(oError);
		},

		_showError: function (sTextKey, oError) {
			MessageBox.error(this.getText(sTextKey), {
				details: this._errorText(oError)
			});
		}
	});
});
